
"""
IntelliWatch — Equipment Vision Service

Responsibilities:
1. Validate uploaded equipment images.
2. Analyse images using Google Gemini.
3. Identify equipment and explain its working principle.
4. Evaluate potential relevance of IntelliWatch sensors.
5. Validate and return structured analysis results.

Security:
- Uses Windows trusted certificates through truststore.
- Maintains standard HTTPS certificate verification.
- Never exposes API keys in logs or responses.
- Processes images in memory without saving them to disk.
"""

import asyncio
import json
import logging
import os
from typing import Any

# Use the operating system's trusted certificate store.
# Keep this before importing Google GenAI and its HTTP dependencies.
import truststore

truststore.inject_into_ssl()

from google import genai
from google.genai import types


logger = logging.getLogger("intelliwatch.vision")


# ============================================================
# 1. SERVICE CONFIGURATION
# ============================================================

MODEL_NAME = "gemini-3.8-flash"

MAX_IMAGE_SIZE = 8 * 1024 * 1024

SUPPORTED_IMAGE_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
}


# ============================================================
# 2. RESPONSE VALIDATION CONFIGURATION
# ============================================================

REQUIRED_FIELDS = {
    "equipment",
    "confidence",
    "purpose",
    "working_principle",
    "intelliwatch_relevance",
    "sensor_compatibility",
    "possible_anomalies",
    "limitations",
}

REQUIRED_SENSOR_FIELDS = {
    "ADXL345",
    "DS18B20",
    "ACS712",
}

VALID_CONFIDENCE_LEVELS = {
    "High",
    "Medium",
    "Low",
}


# ============================================================
# 3. EQUIPMENT ANALYSIS PROMPT
# ============================================================

VISION_PROMPT = """
You are the equipment identification assistant for IntelliWatch,
an industrial equipment monitoring and decision-support system.

Analyse the supplied photograph and return one valid JSON object
with exactly these fields:

{
  "equipment": "Identified equipment or Unknown",
  "confidence": "High, Medium, or Low",
  "purpose": "What the equipment is used for",
  "working_principle": "How it works",
  "intelliwatch_relevance": "Why monitoring it may be useful",
  "sensor_compatibility": {
    "ADXL345": "Vibration monitoring relevance",
    "DS18B20": "Temperature monitoring relevance",
    "ACS712": "Current monitoring relevance"
  },
  "possible_anomalies": [
    "Possible abnormal conditions"
  ],
  "limitations": [
    "What cannot be established from the photograph"
  ]
}

ENGINEERING AND ACCURACY RULES:

1. Identify equipment only when visual evidence supports it.
2. Never invent a model, manufacturer, rating or specification.
3. If identification is uncertain, explicitly say so.
4. Distinguish visible observations from general engineering
   knowledge and assumptions.
5. Explain sensor compatibility as a possible application,
   not proof that sensors are installed.
6. Consider the ADXL345 for vibration-related monitoring.
7. Consider the DS18B20 for suitable contact-temperature
   monitoring applications.
8. Consider the ACS712 for compatible electrical-current
   measurement applications.
9. Do not claim that a sensor alone establishes equipment safety.
10. Do not provide unsupported electrical ratings or safety limits.
11. Do not diagnose an internal fault from appearance alone.
12. If the image is unclear or does not show equipment,
    identify that limitation.
13. Keep explanations technically useful and concise.
14. Return valid JSON only. Do not include Markdown fences.
"""


# ============================================================
# 4. IMAGE VALIDATION
# ============================================================

def _validate_image(
    image_bytes: bytes,
    mime_type: str,
) -> None:
    """Validate image content availability, size and MIME type."""

    if not isinstance(image_bytes, bytes) or not image_bytes:
        raise ValueError("The uploaded image is empty or invalid.")

    if len(image_bytes) > MAX_IMAGE_SIZE:
        raise ValueError("Image exceeds the 8 MB size limit.")

    if mime_type not in SUPPORTED_IMAGE_TYPES:
        raise ValueError("Unsupported image format.")


# ============================================================
# 5. AI RESPONSE VALIDATION
# ============================================================

def _validate_analysis(result: Any) -> dict:
    """Validate the structure returned by the AI model."""

    if not isinstance(result, dict):
        raise RuntimeError(
            "The AI response is not a JSON object."
        )

    if not REQUIRED_FIELDS.issubset(result.keys()):
        raise RuntimeError(
            "The AI response is incomplete."
        )

    string_fields = {
        "equipment",
        "confidence",
        "purpose",
        "working_principle",
        "intelliwatch_relevance",
    }

    for field in string_fields:
        if not isinstance(result.get(field), str):
            raise RuntimeError(
                f"Invalid response field: {field}"
            )

        if not result[field].strip():
            raise RuntimeError(
                f"Empty response field: {field}"
            )

    # Prevent unsupported confidence values.
    if result["confidence"] not in VALID_CONFIDENCE_LEVELS:
        result["confidence"] = "Low"

    # Validate sensor compatibility information.
    sensor_data = result.get("sensor_compatibility")

    if not isinstance(sensor_data, dict):
        raise RuntimeError(
            "Invalid sensor compatibility information."
        )

    for sensor in REQUIRED_SENSOR_FIELDS:
        sensor_value = sensor_data.get(sensor)

        if not isinstance(sensor_value, str) or not sensor_value.strip():
            raise RuntimeError(
                f"Missing or invalid sensor information: {sensor}"
            )

    # Validate anomaly and limitation lists.
    for field in ("possible_anomalies", "limitations"):
        value = result.get(field)

        if not isinstance(value, list):
            raise RuntimeError(
                f"Invalid response list: {field}"
            )

        if not all(
            isinstance(item, str) and item.strip()
            for item in value
        ):
            raise RuntimeError(
                f"Invalid entries in response list: {field}"
            )

    return result


# ============================================================
# 6. EQUIPMENT IMAGE ANALYSIS
# ============================================================

def analyse_equipment_image(
    image_bytes: bytes,
    mime_type: str,
) -> dict:
    """
    Analyse one captured equipment image using Google Gemini.

    Returns:
        dict: Validated equipment analysis.

    Raises:
        ValueError: Invalid image input.
        RuntimeError: AI service or response processing failure.
    """

    # Validate before making an external API request.
    _validate_image(image_bytes, mime_type)

    # Read API credentials securely from the environment.
    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured."
        )

    try:
        # Initialize Gemini client.
        client = genai.Client(
            api_key=api_key
        )

        # Submit the image for equipment analysis.
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=[
                VISION_PROMPT,
                types.Part.from_bytes(
                    data=image_bytes,
                    mime_type=mime_type,
                ),
            ],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
            ),
        )

        # Check whether Gemini returned usable content.
        if not response.text:
            raise RuntimeError(
                "The AI service returned an empty response."
            )

        # Parse structured JSON output.
        try:
            result = json.loads(response.text)

        except json.JSONDecodeError as exc:
            logger.warning(
                "Gemini returned invalid JSON for equipment analysis."
            )

            raise RuntimeError(
                "The AI service returned an invalid analysis response."
            ) from exc

        # Validate before exposing the response to the frontend.
        return _validate_analysis(result)

    except (ValueError, RuntimeError):
        raise

    except Exception as exc:
        logger.exception(
            "Equipment image analysis failed."
        )

        raise RuntimeError(
            "Equipment image analysis service failed."
        ) from exc


# ============================================================
# 7. ASYNCHRONOUS ANALYSIS WRAPPER
# ============================================================

async def analyse_equipment_image_async(
    image_bytes: bytes,
    mime_type: str,
) -> dict:
    """
    Run synchronous Gemini analysis in a worker thread.

    Prevents the synchronous SDK request from blocking
    FastAPI's asynchronous request handling.
    """

    return await asyncio.to_thread(
        analyse_equipment_image,
        image_bytes,
        mime_type,
    )
