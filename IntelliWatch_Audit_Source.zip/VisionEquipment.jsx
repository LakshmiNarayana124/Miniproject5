
import { useEffect, useRef, useState } from "react";

const API_BASE = (
  import.meta.env.VITE_API_URL || "http://localhost:8000"
).replace(/\/+$/, "");

const MAX_IMAGE_SIZE = 8 * 1024 * 1024;
const MAX_FRAME_WIDTH = 640;
const DETECTION_INTERVAL = 500;
const TRACK_IOU_THRESHOLD = 0.3;
const MAX_MISSED_FRAMES = 3;

const SUPPORTED_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
];

function stopMediaStream(stream) {
  if (stream) {
    stream.getTracks().forEach((track) => track.stop());
  }
}

function calculateIoU(a, b) {
  const x1 = Math.max(a.x1, b.x1);
  const y1 = Math.max(a.y1, b.y1);
  const x2 = Math.min(a.x2, b.x2);
  const y2 = Math.min(a.y2, b.y2);

  const intersectionWidth = Math.max(0, x2 - x1);
  const intersectionHeight = Math.max(0, y2 - y1);
  const intersection = intersectionWidth * intersectionHeight;

  const areaA =
    Math.max(0, a.x2 - a.x1) *
    Math.max(0, a.y2 - a.y1);

  const areaB =
    Math.max(0, b.x2 - b.x1) *
    Math.max(0, b.y2 - b.y1);

  const union = areaA + areaB - intersection;

  return union > 0 ? intersection / union : 0;
}

function ResultSection({ title, children }) {
  return (
    <section className="iv-result-section">
      <h3>{title}</h3>
      {children}
    </section>
  );
}

function ResultList({ items, emptyText }) {
  if (!Array.isArray(items) || items.length === 0) {
    return <p className="iv-muted">{emptyText}</p>;
  }

  return (
    <ul className="iv-result-list">
      {items.map((item, index) => (
        <li key={`${index}-${item}`}>{item}</li>
      ))}
    </ul>
  );
}

export default function EquipmentVision() {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const fileInputRef = useRef(null);
  const previewRef = useRef(null);
  const overlayRef = useRef(null);

  const previewUrlRef = useRef("");
  const detectionActiveRef = useRef(false);
  const detectionTimerRef = useRef(null);
  const detectionInFlightRef = useRef(false);

  const tracksRef = useRef([]);
  const nextTrackIdRef = useRef(1);

  const [cameraActive, setCameraActive] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [cameraMessage, setCameraMessage] = useState("");

  const [liveDetection, setLiveDetection] = useState(false);
  const [detectionStatus, setDetectionStatus] = useState("Inactive");
  const [detections, setDetections] = useState([]);

  // ==========================================
  // COMPONENT CLEANUP
  // ==========================================

  useEffect(() => {
    return () => {
      detectionActiveRef.current = false;

      if (detectionTimerRef.current) {
        window.clearTimeout(detectionTimerRef.current);
      }

      stopMediaStream(streamRef.current);

      if (previewUrlRef.current) {
        URL.revokeObjectURL(previewUrlRef.current);
      }
    };
  }, []);

  // ==========================================
  // OBJECT TRACKING
  // ==========================================

  function updateTrackedDetections(currentDetections) {
    const previousTracks = tracksRef.current.map((track) => ({
      ...track,
      missed: track.missed + 1,
    }));

    const updatedTracks = [];
    const usedTrackIds = new Set();

    const trackedResults = currentDetections.map((detection) => {
      let bestTrack = null;
      let bestIoU = TRACK_IOU_THRESHOLD;

      for (const track of previousTracks) {
        if (usedTrackIds.has(track.id)) continue;

        if (track.class_id !== detection.class_id) continue;

        const iou = calculateIoU(track.box, detection);

        if (iou > bestIoU) {
          bestIoU = iou;
          bestTrack = track;
        }
      }

      let trackId;

      if (bestTrack) {
        trackId = bestTrack.id;
        usedTrackIds.add(trackId);
      } else {
        trackId = nextTrackIdRef.current++;
      }

      updatedTracks.push({
        id: trackId,
        class_id: detection.class_id,
        label: detection.label,
        box: {
          x1: detection.x1,
          y1: detection.y1,
          x2: detection.x2,
          y2: detection.y2,
        },
        missed: 0,
      });

      return {
        ...detection,
        track_id: trackId,
      };
    });

    for (const track of previousTracks) {
      if (
        !usedTrackIds.has(track.id) &&
        track.missed <= MAX_MISSED_FRAMES
      ) {
        updatedTracks.push(track);
      }
    }

    tracksRef.current = updatedTracks;

    return trackedResults;
  }

  // ==========================================
  // DRAW DETECTION OVERLAY
  // ==========================================

  function drawDetections() {
    const canvas = overlayRef.current;
    const video = videoRef.current;
    const preview = previewRef.current;

    if (!canvas || !video || !preview) return;

    const width = preview.clientWidth;
    const height = preview.clientHeight;

    if (!width || !height) return;

    const dpr = window.devicePixelRatio || 1;

    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);

    const context = canvas.getContext("2d");

    if (!context) return;

    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.clearRect(0, 0, width, height);

    if (!video.videoWidth || !video.videoHeight) return;

    const videoRect = video.getBoundingClientRect();
    const previewRect = preview.getBoundingClientRect();

    const scale = Math.min(
      videoRect.width / video.videoWidth,
      videoRect.height / video.videoHeight
    );

    const renderedWidth = video.videoWidth * scale;
    const renderedHeight = video.videoHeight * scale;

    const offsetX =
      videoRect.left -
      previewRect.left +
      (videoRect.width - renderedWidth) / 2;

    const offsetY =
      videoRect.top -
      previewRect.top +
      (videoRect.height - renderedHeight) / 2;

    context.lineWidth = 2;
    context.font = "12px Arial";

    for (const detection of detections) {
      const x = offsetX + detection.x1 * renderedWidth;
      const y = offsetY + detection.y1 * renderedHeight;

      const boxWidth =
        (detection.x2 - detection.x1) * renderedWidth;

      const boxHeight =
        (detection.y2 - detection.y1) * renderedHeight;

      if (boxWidth <= 0 || boxHeight <= 0) continue;

      const label =
        `${detection.label} #${detection.track_id} ` +
        `${(detection.confidence * 100).toFixed(0)}%`;

      context.strokeStyle = "#16a34a";
      context.strokeRect(x, y, boxWidth, boxHeight);

      const labelWidth = context.measureText(label).width + 12;
      const labelHeight = 21;

      const labelY = Math.max(0, y - labelHeight);

      context.fillStyle = "rgba(22, 163, 74, 0.92)";
      context.fillRect(
        x,
        labelY,
        labelWidth,
        labelHeight
      );

      context.fillStyle = "#ffffff";
      context.fillText(
        label,
        x + 6,
        labelY + 15
      );
    }
  }

  useEffect(() => {
    drawDetections();

    if (!cameraActive) return;

    const handleResize = () => drawDetections();

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, [detections, cameraActive]);

  // ==========================================
  // STOP LIVE DETECTION
  // ==========================================

  function stopLiveDetection() {
    detectionActiveRef.current = false;

    if (detectionTimerRef.current) {
      window.clearTimeout(detectionTimerRef.current);
      detectionTimerRef.current = null;
    }

    tracksRef.current = [];
    nextTrackIdRef.current = 1;

    setLiveDetection(false);
    setDetections([]);
    setDetectionStatus("Inactive");
  }

  // ==========================================
  // CAMERA CONTROL
  // ==========================================

  function stopCamera() {
    stopLiveDetection();

    stopMediaStream(streamRef.current);
    streamRef.current = null;

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setCameraActive(false);
  }

  async function openCamera() {
    setError("");
    setCameraMessage("");

    if (!navigator.mediaDevices?.getUserMedia) {
      setError(
        "Camera access requires HTTPS or localhost and a supported browser."
      );
      return;
    }

    stopCamera();

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      setCameraActive(true);
    } catch (err) {
      stopMediaStream(streamRef.current);
      streamRef.current = null;

      setCameraActive(false);

      if (err?.name === "NotAllowedError") {
        setError(
          "Camera permission was denied. Allow camera access in your browser settings."
        );
      } else if (err?.name === "NotFoundError") {
        setError("No camera was found on this device.");
      } else {
        setError(
          err?.message || "Unable to open the camera. Please try again."
        );
      }
    }
  }

  // ==========================================
  // LIVE DETECTION — FRAME PROCESSING
  // ==========================================

  function scheduleNextDetection() {
    if (!detectionActiveRef.current) return;

    if (detectionTimerRef.current) {
      window.clearTimeout(detectionTimerRef.current);
    }

    detectionTimerRef.current = window.setTimeout(
      runDetectionFrame,
      DETECTION_INTERVAL
    );
  }

  async function runDetectionFrame() {
    if (
      !detectionActiveRef.current ||
      detectionInFlightRef.current
    ) {
      return;
    }

    const video = videoRef.current;

    if (
      !video ||
      !video.videoWidth ||
      !video.videoHeight
    ) {
      scheduleNextDetection();
      return;
    }

    detectionInFlightRef.current = true;

    try {
      const scale = Math.min(
        1,
        MAX_FRAME_WIDTH / video.videoWidth
      );

      const canvas = document.createElement("canvas");

      canvas.width = Math.round(video.videoWidth * scale);
      canvas.height = Math.round(video.videoHeight * scale);

      const context = canvas.getContext("2d");

      if (!context) {
        throw new Error("Unable to prepare camera frame.");
      }

      context.drawImage(
        video,
        0,
        0,
        canvas.width,
        canvas.height
      );

      const blob = await new Promise((resolve) => {
        canvas.toBlob(resolve, "image/jpeg", 0.72);
      });

      if (!blob) {
        throw new Error("Unable to encode camera frame.");
      }

      if (!detectionActiveRef.current) return;

      const token = sessionStorage.getItem("iw_token");

      if (!token) {
        stopLiveDetection();
        setError("Your session has expired. Please log in again.");
        return;
      }

      const formData = new FormData();

      formData.append(
        "image",
        blob,
        "live-equipment-frame.jpg"
      );

      const response = await fetch(
        `${API_BASE}/vision/detect`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formData,
        }
      );

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        if (
          response.status === 401 ||
          response.status === 403
        ) {
          stopLiveDetection();

          setError(
            "You are not authorised to use live Equipment Vision. Please sign in again or contact your administrator."
          );

          return;
        }

        throw new Error(
          data.detail || "Live object detection failed."
        );
      }

      if (!data.success || !data.detection) {
        throw new Error(
          "The detection service returned an incomplete response."
        );
      }

      if (!detectionActiveRef.current) return;

      const detectedObjects = Array.isArray(
        data.detection.detections
      )
        ? data.detection.detections
        : [];

      const trackedResults =
        updateTrackedDetections(detectedObjects);

      setDetections(trackedResults);

      setDetectionStatus(
        `${trackedResults.length} object(s) detected`
      );

      setError("");
    } catch (err) {
      if (detectionActiveRef.current) {
        setDetectionStatus("Retrying...");
        setError(
          err?.message || "Live detection encountered an error."
        );
      }
    } finally {
      detectionInFlightRef.current = false;

      if (detectionActiveRef.current) {
        scheduleNextDetection();
      }
    }
  }

  function startLiveDetection() {
    if (!cameraActive || !streamRef.current) {
      setError("Open the camera before starting live detection.");
      return;
    }

    const token = sessionStorage.getItem("iw_token");

    if (!token) {
      setError("Your session has expired. Please log in again.");
      return;
    }

    if (detectionActiveRef.current) return;

    setError("");
    tracksRef.current = [];
    nextTrackIdRef.current = 1;

    detectionActiveRef.current = true;

    setLiveDetection(true);
    setDetectionStatus("Starting...");

    runDetectionFrame();
  }

  // ==========================================
  // IMAGE SELECTION
  // ==========================================

  function setSelectedImage(file) {
    if (!file) return;

    if (!SUPPORTED_TYPES.includes(file.type)) {
      setError("Please select a JPEG, PNG or WEBP image.");
      return;
    }

    if (file.size > MAX_IMAGE_SIZE) {
      setError("The image must be smaller than 8 MB.");
      return;
    }

    stopCamera();

    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current);
    }

    const nextPreview = URL.createObjectURL(file);

    previewUrlRef.current = nextPreview;

    setPreviewUrl(nextPreview);
    setImageFile(file);
    setAnalysis(null);
    setError("");
    setCameraMessage("");
  }

  // ==========================================
  // CAPTURE IMAGE
  // ==========================================

  function captureImage() {
    const video = videoRef.current;

    if (!video || !video.videoWidth || !video.videoHeight) {
      setError("The camera is not ready. Please wait and try again.");
      return;
    }

    const maxWidth = 1600;
    const scale = Math.min(1, maxWidth / video.videoWidth);

    const canvas = document.createElement("canvas");

    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);

    const context = canvas.getContext("2d");

    if (!context) {
      setError("Unable to prepare the captured image.");
      return;
    }

    context.drawImage(
      video,
      0,
      0,
      canvas.width,
      canvas.height
    );

    canvas.toBlob(
      (blob) => {
        if (!blob) {
          setError("Image capture failed. Please try again.");
          return;
        }

        if (blob.size > MAX_IMAGE_SIZE) {
          setError("Captured image exceeds the 8 MB size limit.");
          return;
        }

        const file = new File(
          [blob],
          `equipment-capture-${Date.now()}.jpg`,
          { type: "image/jpeg" }
        );

        setSelectedImage(file);
        setCameraMessage("Image captured successfully.");
      },
      "image/jpeg",
      0.88
    );
  }

  // ==========================================
  // FILE UPLOAD
  // ==========================================

  function handleFileChange(event) {
    const file = event.target.files?.[0];

    if (file) {
      setSelectedImage(file);
    }

    event.target.value = "";
  }

  // ==========================================
  // CLEAR IMAGE
  // ==========================================

  function clearImage() {
    stopCamera();

    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current);
      previewUrlRef.current = "";
    }

    setImageFile(null);
    setPreviewUrl("");
    setAnalysis(null);
    setError("");
    setCameraMessage("");
  }

  // ==========================================
  // GEMINI EQUIPMENT ANALYSIS
  // ==========================================

  async function analyseEquipment() {
    if (!imageFile) {
      setError("Capture or upload an equipment image first.");
      return;
    }

    const token = sessionStorage.getItem("iw_token");

    if (!token) {
      setError("Your session has expired. Please log in again.");
      return;
    }

    setLoading(true);
    setError("");
    setAnalysis(null);

    try {
      const formData = new FormData();

      formData.append("image", imageFile);

      const response = await fetch(
        `${API_BASE}/vision/analyse`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
          body: formData,
        }
      );

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        if (
          response.status === 401 ||
          response.status === 403
        ) {
          throw new Error(
            "You are not authorised to use Equipment Vision. Please sign in again or contact your administrator."
          );
        }

        throw new Error(
          data.detail || "Equipment image analysis failed."
        );
      }

      if (!data.success || !data.analysis) {
        throw new Error(
          "The server returned an incomplete analysis."
        );
      }

      setAnalysis(data.analysis);
    } catch (err) {
      setError(
        err?.message || "Unable to analyse the equipment image."
      );
    } finally {
      setLoading(false);
    }
  }

  const sensorCompatibility =
    analysis?.sensor_compatibility || {};

  return (
    <main className="iv-page">
      <style>{`
        .iv-page {
          width: min(1120px, 100%);
          margin: 0 auto;
          padding: 28px 22px 48px;
          color: var(--text-h);
        }

        .iv-heading {
          margin-bottom: 22px;
        }

        .iv-eyebrow {
          color: var(--muted);
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 1.5px;
          text-transform: uppercase;
          margin-bottom: 8px;
        }

        .iv-heading h1 {
          font-size: clamp(24px, 3vw, 32px);
          line-height: 1.2;
          margin: 0 0 9px;
          color: var(--text-h);
        }

        .iv-heading p {
          color: var(--text);
          font-size: 14px;
          line-height: 1.7;
          max-width: 720px;
        }

        .iv-panel {
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: 16px;
          padding: 22px;
          box-shadow: 0 8px 26px rgba(15, 23, 42, 0.04);
        }

        .iv-panel-heading {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          margin-bottom: 16px;
        }

        .iv-panel-heading h2 {
          color: var(--text-h);
          font-size: 16px;
          margin: 0;
        }

        .iv-status {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          color: var(--muted);
          font-size: 11px;
          font-weight: 600;
        }

        .iv-status-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #94a3b8;
        }

        .iv-status-dot.active {
          background: #16a34a;
          box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.12);
        }

        .iv-preview {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 280px;
          max-height: 520px;
          overflow: hidden;
          border: 1px dashed var(--border);
          border-radius: 12px;
          background: var(--bg-card2);
        }

        .iv-preview img,
        .iv-preview video {
          display: block;
          width: 100%;
          max-height: 520px;
          object-fit: contain;
        }

        .iv-preview video {
          position: relative;
          z-index: 1;
        }

        .iv-overlay {
          position: absolute;
          inset: 0;
          z-index: 2;
          width: 100%;
          height: 100%;
          pointer-events: none;
        }

        .iv-placeholder {
          padding: 48px 20px;
          text-align: center;
          color: var(--muted);
        }

        .iv-placeholder-icon {
          font-size: 36px;
          margin-bottom: 12px;
        }

        .iv-placeholder strong {
          display: block;
          color: var(--text-h);
          font-size: 14px;
          margin-bottom: 6px;
        }

        .iv-placeholder span {
          font-size: 12px;
          line-height: 1.6;
        }

        .iv-actions {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          margin-top: 16px;
        }

        .iv-button {
          min-height: 40px;
          border: 1px solid var(--border);
          border-radius: 9px;
          padding: 9px 15px;
          background: var(--bg-card2);
          color: var(--text-h);
          font: inherit;
          font-size: 13px;
          font-weight: 650;
          cursor: pointer;
          transition: opacity .18s ease, transform .18s ease;
        }

        .iv-button:hover:not(:disabled) {
          transform: translateY(-1px);
        }

        .iv-button:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .iv-button-primary {
          color: #fff;
          background: #2563eb;
          border-color: #2563eb;
        }

        .iv-button-secondary {
          background: transparent;
        }

        .iv-button-live {
          color: #fff;
          background: #15803d;
          border-color: #15803d;
        }

        .iv-button-stop {
          color: #fff;
          background: #b91c1c;
          border-color: #b91c1c;
        }

        .iv-detection-status {
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 10px;
          margin-top: 13px;
          padding: 11px 13px;
          border: 1px solid var(--border);
          border-radius: 9px;
          background: var(--bg-card2);
          color: var(--text);
          font-size: 12px;
        }

        .iv-detection-count {
          font-weight: 700;
          color: var(--text-h);
        }

        .iv-note {
          margin-top: 13px;
          color: var(--muted);
          font-size: 11px;
          line-height: 1.6;
        }

        .iv-message {
          margin-top: 14px;
          padding: 12px 14px;
          border-radius: 9px;
          font-size: 13px;
          line-height: 1.5;
        }

        .iv-error {
          color: #b91c1c;
          background: #fee2e2;
          border: 1px solid #fecaca;
        }

        .iv-success {
          color: #166534;
          background: #dcfce7;
          border: 1px solid #bbf7d0;
        }

        .iv-loading {
          display: flex;
          align-items: center;
          gap: 11px;
          margin-top: 16px;
          padding: 15px;
          border-radius: 10px;
          background: var(--bg-card2);
          color: var(--text);
          font-size: 13px;
        }

        .iv-spinner {
          width: 17px;
          height: 17px;
          border: 2px solid var(--border);
          border-top-color: #2563eb;
          border-radius: 50%;
          animation: iv-spin .8s linear infinite;
        }

        @keyframes iv-spin {
          to { transform: rotate(360deg); }
        }

        .iv-results {
          display: grid;
          gap: 14px;
          margin-top: 22px;
        }

        .iv-result-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 14px;
          flex-wrap: wrap;
        }

        .iv-result-header h2 {
          margin: 0 0 5px;
          font-size: 19px;
          color: var(--text-h);
        }

        .iv-result-header p {
          margin: 0;
          color: var(--muted);
          font-size: 12px;
        }

        .iv-confidence {
          border: 1px solid var(--border);
          border-radius: 999px;
          padding: 6px 11px;
          color: var(--text);
          font-size: 11px;
          font-weight: 700;
          white-space: nowrap;
        }

        .iv-result-section {
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: 12px;
          padding: 17px 19px;
        }

        .iv-result-section h3 {
          margin: 0 0 10px;
          color: var(--text-h);
          font-size: 13px;
        }

        .iv-result-section p {
          margin: 0;
          color: var(--text);
          font-size: 13px;
          line-height: 1.7;
          overflow-wrap: anywhere;
        }

        .iv-sensor-row {
          padding: 10px 0;
          border-top: 1px solid var(--border);
        }

        .iv-sensor-row:first-of-type {
          border-top: 0;
          padding-top: 0;
        }

        .iv-sensor-row strong {
          display: block;
          margin-bottom: 4px;
          color: var(--text-h);
          font-size: 12px;
        }

        .iv-result-list {
          margin: 0;
          padding-left: 19px;
          color: var(--text);
          font-size: 13px;
          line-height: 1.8;
        }

        .iv-muted {
          color: var(--muted) !important;
          font-size: 12px !important;
        }

        .iv-disclaimer {
          color: var(--muted);
          font-size: 11px;
          line-height: 1.65;
          margin-top: 3px;
        }

        @media (max-width: 640px) {
          .iv-page {
            padding: 20px 13px 34px;
          }

          .iv-panel {
            padding: 15px;
          }

          .iv-preview {
            min-height: 220px;
          }

          .iv-button {
            flex: 1 1 auto;
          }
        }
      `}</style>

      <header className="iv-heading">
        <div className="iv-eyebrow">
          IntelliWatch · AI-assisted inspection
        </div>

        <h1>Equipment Vision</h1>

        <p>
          Capture or upload an equipment photograph to identify the
          equipment, understand its working principle and explore
          possible monitoring applications using IntelliWatch sensors.
        </p>
      </header>

      <section className="iv-panel">
        <div className="iv-panel-heading">
          <h2>Equipment image</h2>

          <span className="iv-status">
            <span
              className={`iv-status-dot ${cameraActive ? "active" : ""}`}
            />

            {cameraActive ? "Camera active" : "Camera inactive"}
          </span>
        </div>

        <div className="iv-preview" ref={previewRef}>
          {previewUrl ? (
            <img
              src={previewUrl}
              alt="Selected equipment preview"
            />
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                aria-label="Camera preview"
                style={{
                  display: cameraActive ? "block" : "none",
                }}
              />

              {cameraActive && (
                <canvas
                  ref={overlayRef}
                  className="iv-overlay"
                  aria-hidden="true"
                />
              )}

              {!cameraActive && (
                <div className="iv-placeholder">
                  <div className="iv-placeholder-icon">📷</div>

                  <strong>No equipment image selected</strong>

                  <span>
                    Open the camera to capture an image, or upload
                    an existing equipment photograph.
                  </span>
                </div>
              )}
            </>
          )}
        </div>

        <div className="iv-actions">
          {!previewUrl && !cameraActive && (
            <button
              type="button"
              className="iv-button iv-button-primary"
              onClick={openCamera}
              disabled={loading}
            >
              Open camera
            </button>
          )}

          {cameraActive && (
            <>
              <button
                type="button"
                className="iv-button iv-button-primary"
                onClick={captureImage}
                disabled={loading}
              >
                Capture image
              </button>

              {!liveDetection ? (
                <button
                  type="button"
                  className="iv-button iv-button-live"
                  onClick={startLiveDetection}
                  disabled={loading}
                >
                  Start live detection
                </button>
              ) : (
                <button
                  type="button"
                  className="iv-button iv-button-stop"
                  onClick={stopLiveDetection}
                  disabled={loading}
                >
                  Stop live detection
                </button>
              )}

              <button
                type="button"
                className="iv-button iv-button-secondary"
                onClick={stopCamera}
                disabled={loading}
              >
                Close camera
              </button>
            </>
          )}

          <button
            type="button"
            className="iv-button"
            onClick={() => fileInputRef.current?.click()}
            disabled={loading}
          >
            Upload image
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            capture="environment"
            onChange={handleFileChange}
            hidden
          />

          {previewUrl && (
            <>
              <button
                type="button"
                className="iv-button iv-button-primary"
                onClick={analyseEquipment}
                disabled={loading}
              >
                {loading ? "Analysing..." : "Analyse equipment"}
              </button>

              <button
                type="button"
                className="iv-button iv-button-secondary"
                onClick={clearImage}
                disabled={loading}
              >
                Clear image
              </button>
            </>
          )}
        </div>

        {cameraActive && (
          <div className="iv-detection-status">
            <span>
              Live detection: <strong>{detectionStatus}</strong>
            </span>

            <span className="iv-detection-count">
              {detections.length} visible object(s)
            </span>
          </div>
        )}

        {cameraMessage && (
          <div className="iv-message iv-success" role="status">
            {cameraMessage}
          </div>
        )}

        {error && (
          <div className="iv-message iv-error" role="alert">
            {error}
          </div>
        )}

        {loading && (
          <div
            className="iv-loading"
            role="status"
            aria-live="polite"
          >
            <span className="iv-spinner" />

            <span>
              Analysing the captured image. This may take a few moments.
            </span>
          </div>
        )}

        <p className="iv-note">
          Live detection sends sampled camera frames to the backend
          while enabled. Frames are processed in memory and are not
          persistently recorded or saved. Gemini analysis is performed
          separately on the selected still image. Supported formats:
          JPEG, PNG and WEBP. Maximum image size: 8 MB.
        </p>

        <p className="iv-note">
          Detection uses a general-purpose COCO object model. It can
          recognise supported everyday object categories, but may not
          identify specialised industrial machinery, internal faults
          or machine-specific components. Detection results are not
          certified equipment inspections.
        </p>
      </section>

      {analysis && (
        <div className="iv-results" aria-live="polite">
          <section className="iv-panel">
            <div className="iv-result-header">
              <div>
                <div className="iv-eyebrow">Analysis result</div>

                <h2>
                  {analysis.equipment || "Equipment not identified"}
                </h2>

                <p>
                  AI-generated visual identification. Verify the
                  equipment identity against its physical label
                  or technical documentation.
                </p>
              </div>

              <span className="iv-confidence">
                Confidence: {analysis.confidence || "Not specified"}
              </span>
            </div>
          </section>

          <ResultSection title="Purpose">
            <p>{analysis.purpose}</p>
          </ResultSection>

          <ResultSection title="Working principle">
            <p>{analysis.working_principle}</p>
          </ResultSection>

          <ResultSection title="IntelliWatch relevance">
            <p>{analysis.intelliwatch_relevance}</p>
          </ResultSection>

          <ResultSection title="Sensor compatibility">
            {Object.entries(sensorCompatibility).map(
              ([sensor, explanation]) => (
                <div className="iv-sensor-row" key={sensor}>
                  <strong>{sensor}</strong>
                  <p>{explanation}</p>
                </div>
              )
            )}
          </ResultSection>

          <ResultSection title="Possible anomalies">
            <ResultList
              items={analysis.possible_anomalies}
              emptyText="No possible anomalies were listed."
            />
          </ResultSection>

          <ResultSection title="Limitations">
            <ResultList
              items={analysis.limitations}
              emptyText="No additional limitations were listed."
            />
          </ResultSection>

          <p className="iv-disclaimer">
            This is an AI-assisted visual assessment, not a certified
            engineering inspection. A photograph cannot establish
            internal condition, electrical safety, actual sensor
            installation or equipment operating limits. Do not use
            this result as the sole basis for maintenance or safety
            decisions.
          </p>
        </div>
      )}
    </main>
  );
}
