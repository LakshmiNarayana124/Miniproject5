// ==================================================
// INTELLIWATCH — GLOBAL I18N TRANSLATIONS
// Languages: en, hi, kn, ta, te
// Usage: import { t, setLang, getLang } from './i18n'
// All UI components read from this module.
// ==================================================

export const SUPPORTED_LANGUAGES = [
  { code: 'en', label: 'EN', name: 'English', flag: '🇬🇧' },
  { code: 'hi', label: 'HI', name: 'हिन्दी', flag: '🇮🇳' },
  { code: 'kn', label: 'KN', name: 'ಕನ್ನಡ', flag: '🇮🇳' },
  { code: 'ta', label: 'TA', name: 'தமிழ்', flag: '🇮🇳' },
  { code: 'te', label: 'TE', name: 'తెలుగు', flag: '🇮🇳' },
]

const TRANSLATIONS = {

  // ─── Navigation ────────────────────────────────────────────────────────────
  nav_home:        { en: 'Home', hi: 'होम', kn: 'ಮನೆ', ta: 'முகப்பு', te: 'హోమ్' },
  nav_vibration:   { en: 'Vibration', hi: 'कंपन', kn: 'ಕಂಪನ', ta: 'அதிர்வு', te: 'కంపనం' },
  nav_temperature: { en: 'Temperature', hi: 'तापमान', kn: 'ತಾಪಮಾನ', ta: 'வெப்பநிலை', te: 'ఉష్ణోగ్రత' },
  nav_current:     { en: 'Current', hi: 'करंट', kn: 'ವಿದ್ಯುತ್', ta: 'மின்னோட்டம்', te: 'కరెంట్' },
  nav_explorer:    { en: '3D Lab', hi: '3D लैब', kn: '3D ಲ್ಯಾಬ್', ta: '3D ஆய்வகம்', te: '3D లాబ్' },
  nav_vision: {
    en: 'Equipment Vision',
    hi: 'उपकरण निरीक्षण',
    kn: 'ಉಪಕರಣ ಪರಿಶೀಲನೆ',
    ta: 'உபகரண ஆய்வு',
    te: 'పరికరాల తనిఖీ'
  },
  nav_about:       { en: 'About', hi: 'परिचय', kn: 'ಬಗ್ಗೆ', ta: 'பற்றி', te: 'గురించి' },
  nav_users:       { en: 'Users', hi: 'उपयोगकर्ता', kn: 'ಬಳಕೆದಾರರು', ta: 'பயனர்கள்', te: 'వినియోగదారులు' },

  // ─── Auth / Login ──────────────────────────────────────────────────────────
  login_tagline: {
    en: 'Anomaly Detection & Decision Support',
    hi: 'Anomaly Detection और Decision Support',
    kn: 'Anomaly Detection ಮತ್ತು Decision Support',
    ta: 'முரண்பாடு கண்டறிதல் மற்றும் முடிவு ஆதரவு',
    te: 'అనామలీ డిటెక్షన్ మరియు నిర్ణయ మద్దతు'
  },
  sign_in: {
    en: 'Sign in to your workspace',
    hi: 'अपने workspace में साइन इन करें',
    kn: 'ನಿಮ್ಮ workspace ಗೆ ಸೈನ್ ಇನ್ ಮಾಡಿ',
    ta: 'உங்கள் workspace இல் உள்நுழைக',
    te: 'మీ workspace లో సైన్ ఇన్ చేయండి'
  },
  username_label: {
    en: 'Username',
    hi: 'उपयोगकर्ता नाम',
    kn: 'ಬಳಕೆದಾರ ಹೆಸರು',
    ta: 'பயனர் பெயர்',
    te: 'వినియోగదారు పేరు'
  },
  username_placeholder: {
    en: 'Enter your username',
    hi: 'उपयोगकर्ता नाम दर्ज करें',
    kn: 'ನಿಮ್ಮ ಬಳಕೆದಾರ ಹೆಸರು ನಮೂದಿಸಿ',
    ta: 'பயனர் பெயரை உள்ளிடுக',
    te: 'వినియోగదారు పేరు నమోదు చేయండి'
  },
  password_label: {
    en: 'Password',
    hi: 'पासवर्ड',
    kn: 'ಪಾಸ್‌ವರ್ಡ್',
    ta: 'கடவுச்சொல்',
    te: 'పాస్‌వర్డ్'
  },
  password_placeholder: {
    en: 'Enter your password',
    hi: 'पासवर्ड दर्ज करें',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ',
    ta: 'கடவுச்சொல்லை உள்ளிடுக',
    te: 'పాస్‌వర్డ్ నమోదు చేయండి'
  },
  show_password: {
    en: 'Show password',
    hi: 'पासवर्ड दिखाएं',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ತೋರಿಸಿ',
    ta: 'கடவுச்சொல் காட்டு',
    te: 'పాస్‌వర్డ్ చూపు'
  },
  hide_password: {
    en: 'Hide password',
    hi: 'पासवर्ड छुपाएं',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ಮರೆಮಾಡಿ',
    ta: 'கடவுச்சொல் மறை',
    te: 'పాస్‌వర్డ్ దాచు'
  },
  sign_in_btn: {
    en: '→ Sign In',
    hi: '→ साइन इन',
    kn: '→ ಸೈನ್ ಇನ್',
    ta: '→ உள்நுழை',
    te: '→ సైన్ ఇన్'
  },
  logout_btn: {
    en: '⏏ Out',
    hi: '⏏ बाहर',
    kn: '⏏ ಹೊರಗೆ',
    ta: '⏏ வெளியேறு',
    te: '⏏ వెళ్ళు'
  },
  sign_out: {
    en: 'Sign out',
    hi: 'साइन आउट',
    kn: 'ಸೈನ್ ಔಟ್',
    ta: 'வெளியேறு',
    te: 'సైన్ అవుట్'
  },
  theme_dark: {
    en: 'Dark Mode',
    hi: 'डार्क मोड',
    kn: 'ಡಾರ್ಕ್ ಮೋಡ್',
    ta: 'டார்க் மோட்',
    te: 'డార్క్ మోడ్'
  },
  theme_light: {
    en: 'Light Mode',
    hi: 'लाइट मोड',
    kn: 'ಲೈಟ್ ಮೋಡ್',
    ta: 'லைட் மோட்',
    te: 'లైట్ మోడ్'
  },
  theme_switch_dark: {
    en: 'Switch to dark mode',
    hi: 'डार्क मोड पर स्विच करें',
    kn: 'ಡಾರ್ಕ್ ಮೋಡ್‌ಗೆ ಬದಲಿ',
    ta: 'டார்க் மோட்டிற்கு மாறு',
    te: 'డార్క్ మోడ్‌కి మారు'
  },
  theme_switch_light: {
    en: 'Switch to light mode',
    hi: 'लाइट मोड पर स्विच करें',
    kn: 'ಲೈಟ್ ಮೋಡ್‌ಗೆ ಬದಲಿ',
    ta: 'லைட் மோட்டிற்கு மாறு',
    te: 'లైట్ మోడ్‌కి మారు'
  },
  login_error_empty: {
    en: 'Please enter your username and password.',
    hi: 'कृपया उपयोगकर्ता नाम और पासवर्ड दर्ज करें।',
    kn: 'ದಯವಿಟ್ಟು ಬಳಕೆದಾರ ಹೆಸರು ಮತ್ತು ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ.',
    ta: 'பயனர் பெயர் மற்றும் கடவுச்சொல்லை உள்ளிடவும்.',
    te: 'వినియోగదారు పేరు మరియు పాస్‌వర్డ్ నమోదు చేయండి.'
  },
  login_error_invalid: {
    en: 'Invalid username or password.',
    hi: 'गलत उपयोगकर्ता नाम या पासवर्ड।',
    kn: 'ತಪ್ಪಾದ ಬಳಕೆದಾರ ಹೆಸರು ಅಥವಾ ಪಾಸ್‌ವರ್ಡ್.',
    ta: 'தவறான பயனர் பெயர் அல்லது கடவுச்சொல்.',
    te: 'తప్పు వినియోగదారు పేరు లేదా పాస్‌వర్డ్.'
  },
  login_error_offline: {
    en: 'Cannot reach the server. Use "demo" / "demo" for offline mode.',
    hi: 'सर्वर तक नहीं पहुँचा। ऑफलाइन मोड के लिए "demo" / "demo" उपयोग करें।',
    kn: 'ಸರ್ವರ್ ತಲುಪಲು ಸಾಧ್ಯವಿಲ್ಲ. ಆಫ್‌ಲೈನ್ ಮೋಡ್‌ಗಾಗಿ "demo" / "demo" ಬಳಸಿ.',
    ta: 'சர்வர் கிடைக்கவில்லை. ஆஃப்லைன் மோட்டிற்கு "demo" / "demo" பயன்படுத்துக.',
    te: 'సర్వర్ చేరుకోలేకపోయింది. ఆఫ్‌లైన్ మోడ్‌కు "demo" / "demo" వాడండి.'
  },
  offline_hint: {
    en: 'Offline demo: username demo / password demo',
    hi: 'ऑफलाइन डेमो: username demo / password demo',
    kn: 'ಆಫ್‌ಲೈನ್ ಡೆಮೊ: username demo / password demo',
    ta: 'ஆஃப்லைன் டெமோ: username demo / password demo',
    te: 'ఆఫ్‌లైన్ డెమో: username demo / password demo'
  },
  role_admin: {
    en: 'ADMIN', hi: 'ADMIN', kn: 'ADMIN', ta: 'ADMIN', te: 'ADMIN'
  },
  role_operator: {
    en: 'OPERATOR', hi: 'OPERATOR', kn: 'OPERATOR', ta: 'OPERATOR', te: 'OPERATOR'
  },
  role_engineer: {
    en: 'MAINTENANCE ENGINEER',
    hi: 'MAINTENANCE ENGINEER',
    kn: 'MAINTENANCE ENGINEER',
    ta: 'MAINTENANCE ENGINEER',
    te: 'MAINTENANCE ENGINEER'
  },

  // ─── System status labels ──────────────────────────────────────────────────
  status_normal: {
    en: 'Normal', hi: 'सामान्य', kn: 'ಸಾಮಾನ್ಯ', ta: 'சாதாரண', te: 'సాధారణ'
  },
  status_warning: {
    en: 'Warning', hi: 'चेतावनी', kn: 'ಎಚ್ಚರಿಕೆ', ta: 'எச்சரிக்கை', te: 'హెచ్చరిక'
  },
  status_critical: {
    en: 'Critical', hi: 'गंभीर', kn: 'ಗಂಭೀರ', ta: 'நெருக்கடி', te: 'క్రిటికల్'
  },
  status_awaiting: {
    en: 'Awaiting IoT Signal',
    hi: 'IoT संकेत का इंतजार',
    kn: 'IoT ಸಿಗ್ನಲ್ ನಿರೀಕ್ಷೆ',
    ta: 'IoT சமிக்ஞை எதிர்பார்க்கிறது',
    te: 'IoT సిగ్నల్ కోసం వేచి ఉంది'
  },
  status_uncertain: {
    en: 'Uncertain', hi: 'अनिश्चित', kn: 'ಅನಿಶ್ಚಿತ', ta: 'நிச்சயமற்றது', te: 'అనిశ్చితం'
  },
  status_scanning: {
    en: 'Scanning', hi: 'स्कैनिंग', kn: 'ಸ್ಕ್ಯಾನಿಂಗ್', ta: 'ஸ்கேனிங்', te: 'స్కానింగ్'
  },
  status_ready: {
    en: 'Ready', hi: 'तैयार', kn: 'ಸಿದ್ಧ', ta: 'தயார்', te: 'రెడీ'
  },
  status_no_data: {
    en: 'No Data', hi: 'कोई डेटा नहीं', kn: 'ಡೇಟಾ ಇಲ್ಲ', ta: 'தரவு இல்லை', te: 'డేటా లేదు'
  },

  // ─── System Overview ───────────────────────────────────────────────────────
  sys_overview_normal: {
    en: 'All Systems Normal',
    hi: 'सभी सिस्टम सामान्य',
    kn: 'ಎಲ್ಲ ವ್ಯವಸ್ಥೆಗಳು ಸಾಮಾನ್ಯ',
    ta: 'அனைத்து அமைப்புகளும் சாதாரண',
    te: 'అన్ని సిస్టమ్‌లు సాధారణం'
  },
  sys_overview_warning: {
    en: 'Warning Detected',
    hi: 'चेतावनी पहचानी गई',
    kn: 'ಎಚ್ಚರಿಕೆ ಪತ್ತೆ',
    ta: 'எச்சரிக்கை கண்டறியப்பட்டது',
    te: 'హెచ్చరిక గుర్తించబడింది'
  },
  sys_overview_critical: {
    en: 'Critical Anomaly — Equipment Stopping',
    hi: 'गंभीर विसंगति — उपकरण रोका जा रहा है',
    kn: 'ಗಂಭೀರ ವ್ಯತ್ಯಾಸ — ಉಪಕರಣ ನಿಲ್ಲಿಸಲಾಗುತ್ತಿದೆ',
    ta: 'நெருக்கடி — உபகரணம் நிறுத்தப்படுகிறது',
    te: 'క్రిటికల్ — పరికరం ఆపబడుతోంది'
  },
  sys_overview_awaiting: {
    en: 'Awaiting IoT Connection',
    hi: 'IoT कनेक्शन का इंतजार',
    kn: 'IoT ಸಂಪರ್ಕ ನಿರೀಕ್ಷೆ',
    ta: 'IoT இணைப்பு எதிர்பார்க்கிறது',
    te: 'IoT కనెక్షన్ కోసం వేచి ఉంది'
  },
  sys_overview_uncertain: {
    en: 'Uncertain — Verifying Sensors',
    hi: 'अनिश्चित — सेंसर सत्यापन',
    kn: 'ಅನಿಶ್ಚಿತ — Sensor ಪರಿಶೀಲನೆ',
    ta: 'நிச்சயமற்றது — சென்சார் சரிபார்ப்பு',
    te: 'అనిశ్చితం — సెన్సర్ ధృవీకరణ'
  },

  sys_msg_normal: {
    en: 'All sensors are operating within safe thresholds. Continuous monitoring is active.',
    hi: 'सभी सेंसर सुरक्षित सीमाओं में चल रहे हैं। निरंतर निगरानी सक्रिय है।',
    kn: 'ಎಲ್ಲ sensors ಸುರಕ್ಷಿತ ಮಿತಿಯಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿವೆ.',
    ta: 'அனைத்து சென்சார்களும் பாதுகாப்பான வரம்பிற்குள் இயங்குகின்றன.',
    te: 'అన్ని సెన్సర్‌లు సురక్షిత పరిధిలో పని చేస్తున్నాయి.'
  },
  sys_msg_warning: {
    en: 'Elevated readings detected. Equipment speed is being reduced gradually to prevent damage.',
    hi: 'उच्च रीडिंग पहचानी गई। नुकसान से बचाने के लिए उपकरण की गति धीरे-धीरे कम की जा रही है।',
    kn: 'ಹೆಚ್ಚಿನ ಮಿತಿ ಪತ್ತೆ. ಹಾನಿ ತಡೆಯಲು ಉಪಕರಣ ವೇಗ ಕ್ರಮೇಣ ಕಡಿಮೆ ಮಾಡಲಾಗುತ್ತಿದೆ.',
    ta: 'அதிக அளவீடு கண்டறியப்பட்டது. சேதத்தை தடுக்க வேகம் படிப்படியாக குறைக்கப்படுகிறது.',
    te: 'ఎక్కువ రీడింగ్ గుర్తించబడింది. నష్టాన్ని నివారించడానికి పరికర వేగం క్రమంగా తగ్గించబడుతోంది.'
  },
  sys_msg_critical: {
    en: 'Critical threshold breached. Equipment stop command issued to protect hardware from damage.',
    hi: 'गंभीर सीमा पार हो गई। हार्डवेयर को नुकसान से बचाने के लिए उपकरण रोकने का आदेश जारी।',
    kn: 'ಗಂಭೀರ ಮಿತಿ ಮೀರಿದೆ. Hardware ಹಾನಿ ತಡೆಯಲು ಉಪಕರಣ ನಿಲ್ಲಿಸುವ ಆದೇಶ ನೀಡಲಾಗಿದೆ.',
    ta: 'நெருக்கடி வரம்பு மீறப்பட்டது. வன்பொருள் சேதத்தை தடுக்க நிறுத்த உத்தரவு பிறப்பிக்கப்பட்டது.',
    te: 'క్రిటికల్ పరిమితి దాటింది. హార్డ్‌వేర్ నష్టాన్ని నివారించడానికి పరికరం ఆపు ఆదేశం జారీ అయింది.'
  },
  sys_msg_awaiting: {
    en: 'IntelliWatch is ready. Connect the IoT hardware to start real-time monitoring.',
    hi: 'IntelliWatch तैयार है। real-time monitoring शुरू करने के लिए IoT hardware कनेक्ट करें।',
    kn: 'IntelliWatch ಸಿದ್ಧ. Real-time monitoring ಪ್ರಾರಂಭಿಸಲು IoT hardware ಸಂಪರ್ಕಿಸಿ.',
    ta: 'IntelliWatch தயார். நேரடி கண்காணிப்பு தொடங்க IoT hardware ஐ இணைக்கவும்.',
    te: 'IntelliWatch రెడీ. రియల్-టೈమ్ మానిటరింగ్ ప్రారంభించడానికి IoT హార్డ్‌వేర్ కనెక్ట్ చేయండి.'
  },

  // ─── Connection status ─────────────────────────────────────────────────────
  conn_live: {
    en: '🟢 Live', hi: '🟢 सीधा', kn: '🟢 ನೇರ', ta: '🟢 நேரடி', te: '🟢 లైవ్'
  },
  conn_polling: {
    en: '🟡 Polling', hi: '🟡 पोलिंग', kn: '🟡 Polling', ta: '🟡 பயிற்சி', te: '🟡 పోలింగ్'
  },
  conn_connecting: {
    en: '🔵 Connecting…',
    hi: '🔵 कनेक्ट हो रहा है…',
    kn: '🔵 ಸಂಪರ್ಕಿಸಲಾಗುತ್ತಿದೆ…',
    ta: '🔵 இணைக்கிறது…',
    te: '🔵 కనెక్ట్ అవుతోంది…'
  },
  conn_offline: {
    en: '🔴 Offline', hi: '🔴 ऑफलाइन', kn: '🔴 ಆಫ್‌ಲೈನ್', ta: '🔴 ஆஃப்லைன்', te: '🔴 ఆఫ్‌లైన్'
  },

  // ─── Last session banner ───────────────────────────────────────────────────
  last_session_label: {
    en: 'Last session:',
    hi: 'पिछला सत्र:',
    kn: 'ಕೊನೆಯ ಸೆಶನ್:',
    ta: 'கடந்த அமர்வு:',
    te: 'చివరి సెషన్:'
  },
  dismiss: {
    en: 'Dismiss', hi: 'बंद करें', kn: 'ವಜಾ ಮಾಡಿ', ta: 'நிராகரி', te: 'విస్మరించు'
  },

  // ─── Action banners ────────────────────────────────────────────────────────
  action_critical_title: {
    en: '🛑 Equipment Stop Activated',
    hi: '🛑 उपकरण रोक सक्रिय',
    kn: '🛑 ಉಪಕರಣ ನಿಲ್ಲಿಸುವಿಕೆ ಸಕ್ರಿಯ',
    ta: '🛑 உபகரண நிறுத்தம் இயக்கப்பட்டது',
    te: '🛑 పరికరం ఆపు సక్రియమైంది'
  },
  action_critical_body: {
    en: 'Sensor reading has exceeded the critical threshold. The system has issued an immediate stop command. Do not restart until the fault is inspected and cleared.',
    hi: 'सेंसर रीडिंग गंभीर सीमा पार कर गई। सिस्टम ने तत्काल रोक आदेश जारी किया। खराबी की जांच और सुधार होने तक पुनः आरंभ न करें।',
    kn: 'Sensor ಮಿತಿ ಮೀರಿದೆ. ಸಿಸ್ಟಮ್ ತಕ್ಷಣ ನಿಲ್ಲಿಸುವ ಆದೇಶ ನೀಡಿದೆ. ದೋಷ ಪರೀಕ್ಷೆ ತನಕ ಪುನಃ ಚಾಲನೆ ಮಾಡಬೇಡಿ.',
    ta: 'சென்சார் வரம்பை மீறியது. உடனடி நிறுத்த கட்டளை பிறப்பிக்கப்பட்டது. கோளாறு சரிசெய்யும் வரை மறுதொடக்கம் செய்யாதீர்கள்.',
    te: 'సెన్సర్ క్రిటికల్ పరిమితి దాటింది. వెంటనే ఆపు ఆదేశం జారీ అయింది. లోపం సరిచేసే వరకు తిరిగి ప్రారంభించవద్దు.'
  },
  action_warning_title: {
    en: '⚠️ Gradual Speed Reduction in Progress',
    hi: '⚠️ क्रमिक गति में कमी जारी',
    kn: '⚠️ ಕ್ರಮೇಣ ವೇಗ ಕಡಿತ ಪ್ರಗತಿಯಲ್ಲಿ',
    ta: '⚠️ படிப்படியான வேக குறைப்பு நடக்கிறது',
    te: '⚠️ క్రమంగా వేగ తగ్గింపు జరుగుతోంది'
  },
  action_warning_body: {
    en: 'Readings are elevated but within manageable range. The system is smoothly reducing operational speed to bring values back to normal without abrupt stops.',
    hi: 'रीडिंग बढ़ी हुई है लेकिन प्रबंधनीय सीमा में है। सिस्टम अचानक रोके बिना मानों को सामान्य पर लाने के लिए धीरे-धीरे गति कम कर रहा है।',
    kn: 'Readings ಹೆಚ್ಚಿವೆ ಆದರೆ ನಿರ್ವಹಣೀಯ ವ್ಯಾಪ್ತಿಯಲ್ಲಿದೆ. ಹಠಾತ್ ನಿಲ್ಲಿಸದೆ ಮೌಲ್ಯಗಳನ್ನು ಸಾಮಾನ್ಯಕ್ಕೆ ತರಲು ವೇಗ ಕ್ರಮೇಣ ಕಡಿಮೆ ಮಾಡಲಾಗುತ್ತಿದೆ.',
    ta: 'அளவீடுகள் உயர்ந்துள்ளன ஆனால் கட்டுப்படுத்தக்கூடிய வரம்பில் உள்ளன. திடீர் நிறுத்தம் இல்லாமல் வேகம் படிப்படியாக குறைக்கப்படுகிறது.',
    te: 'రీడింగ్‌లు పెరిగాయి కానీ నిర్వహించదగిన పరిధిలో ఉన్నాయి. ఆకస్మిక ఆపు లేకుండా వేగం క్రమంగా తగ్గించబడుతోంది.'
  },
  action_normal_title: {
    en: '✅ Continuous Analysis Active',
    hi: '✅ निरंतर विश्लेषण सक्रिय',
    kn: '✅ ನಿರಂತರ ವಿಶ್ಲೇಷಣೆ ಸಕ್ರಿಯ',
    ta: '✅ தொடர்ச்சியான பகுப்பாய்வு செயலில்',
    te: '✅ నిరంతర విశ్లేషణ సక్రియంగా ఉంది'
  },
  action_normal_body: {
    en: 'All readings are within the safe operating range. IntelliWatch is performing steady background analysis. No action required.',
    hi: 'सभी रीडिंग सुरक्षित संचालन सीमा में हैं। IntelliWatch स्थिर पृष्ठभूमि विश्लेषण कर रहा है। कोई कार्रवाई आवश्यक नहीं।',
    kn: 'ಎಲ್ಲ readings ಸುರಕ್ಷಿತ ಮಿತಿಯಲ್ಲಿವೆ. IntelliWatch ಸ್ಥಿರ ಹಿನ್ನೆಲೆ ವಿಶ್ಲೇಷಣೆ ನಡೆಸುತ್ತಿದೆ. ಯಾವ ಕ್ರಮ ಅಗತ್ಯವಿಲ್ಲ.',
    ta: 'அனைத்து அளவீடுகளும் பாதுகாப்பான வரம்பிற்குள் உள்ளன. IntelliWatch நிலையான பின்னணி பகுப்பாய்வு செய்கிறது. எந்த நடவடிக்கையும் தேவையில்லை.',
    te: 'అన్ని రీడింగ్‌లు సురక్షిత పరిధిలో ఉన్నాయి. IntelliWatch స్థిర నేపథ్య విశ్లేషణ నిర్వహిస్తోంది. ఎలాంటి చర్య అవసరం లేదు.'
  },
  action_uncertain_title: {
    en: '🔍 Verifying Sensor Data',
    hi: '🔍 सेंसर डेटा सत्यापित हो रहा है',
    kn: '🔍 Sensor ಡೇಟಾ ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ',
    ta: '🔍 சென்சார் தரவு சரிபார்க்கப்படுகிறது',
    te: '🔍 సెన్సర్ డేటా ధృవీకరిస్తోంది'
  },
  action_uncertain_body: {
    en: 'Readings are being cross-checked against known baselines. Stand by.',
    hi: 'रीडिंग ज्ञात आधार रेखाओं के विरुद्ध जांची जा रही है। कृपया प्रतीक्षा करें।',
    kn: 'ಪರಿಚಿತ ಮಾನದಂಡಗಳ ವಿರುದ್ಧ Readings ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ. ನಿರೀಕ್ಷಿಸಿ.',
    ta: 'அளவீடுகள் அறியப்பட்ட அடிப்படைகளுடன் சரிபார்க்கப்படுகின்றன. காத்திருக்கவும்.',
    te: 'రీడింగ్‌లు తెలిసిన బేస్‌లైన్‌లతో పోల్చి చూస్తున్నారు. వేచి ఉండండి.'
  },

  // ─── Sensor page labels ────────────────────────────────────────────────────
  sensor_not_found: {
    en: 'Sensor not found.',
    hi: 'सेंसर नहीं मिला।',
    kn: 'Sensor ಕಂಡುಬಂದಿಲ್ಲ.',
    ta: 'சென்சார் கிடைக்கவில்லை.',
    te: 'సెన్సర్ కనుగొనబడలేదు.'
  },
  iot_status_label: {
    en: 'Status', hi: 'स्थिति', kn: 'ಸ್ಥಿತಿ', ta: 'நிலை', te: 'స్థితి'
  },
  tooltip_no_signal: {
    en: '— No signal',
    hi: '— कोई सिग्नल नहीं',
    kn: '— ಯಾವ ಸಿಗ್ನಲ್ ಇಲ್ಲ',
    ta: '— சமிக்ஞை இல்லை',
    te: '— సిగ్నల్ లేదు'
  },
  live_reading: {
    en: 'Live Reading',
    hi: 'लाइव रीडिंग',
    kn: 'ನೇರ ಓದುವಿಕೆ',
    ta: 'நேரடி அளவீடு',
    te: 'లైవ్ రీడింగ్'
  },
  awaiting_iot: {
    en: '🔌 Awaiting IoT Signal',
    hi: '🔌 IoT सिग्नल का इंतजार',
    kn: '🔌 IoT ಸಿಗ್ನಲ್ ನಿರೀಕ್ಷೆ',
    ta: '🔌 IoT சமிக்ஞை எதிர்பார்க்கிறது',
    te: '🔌 IoT సిగ్నల్ కోసం వేచి ఉంది'
  },
  awaiting_iot_body: {
    en: 'IntelliWatch is ready. Monitoring and analysis will begin automatically when a valid sensor signal is received.',
    hi: 'IntelliWatch तैयार है। वैध सेंसर सिग्नल मिलने पर निगरानी और विश्लेषण स्वतः शुरू होगा।',
    kn: 'IntelliWatch ಸಿದ್ಧ. ಮಾನ್ಯ sensor signal ಬಂದಾಗ ಮೇಲ್ವಿಚಾರಣೆ ಸ್ವತಃ ಪ್ರಾರಂಭ.',
    ta: 'IntelliWatch தயார். சரியான சென்சார் சமிக்ஞை கிடைக்கும்போது கண்காணிப்பு தொடங்கும்.',
    te: 'IntelliWatch రెడీ. చెల్లుబాటు అయ్యే సెన్సర్ సిగ్నల్ వచ్చినప్పుడు మానిటరింగ్ స్వయంచాలకంగా ప్రారంభమవుతుంది.'
  },
  chart_title: {
    en: 'Real-time Chart',
    hi: 'रियल-टाइम चार्ट',
    kn: 'ನೇರ-ಸಮಯ ಚಾರ್ಟ್',
    ta: 'நேரடி-நேர விளக்கப்படம்',
    te: 'రియల్-టైమ్ చార్ట్'
  },
  warn_threshold: {
    en: 'Warning threshold',
    hi: 'चेतावनी सीमा',
    kn: 'ಎಚ್ಚರಿಕೆ ಮಿತಿ',
    ta: 'எச்சரிக்கை வரம்பு',
    te: 'హెచ్చరిక పరిమితి'
  },
  crit_threshold: {
    en: 'Critical threshold',
    hi: 'गंभीर सीमा',
    kn: 'ಗಂಭೀರ ಮಿತಿ',
    ta: 'நெருக்கடி வரம்பு',
    te: 'క్రిటికల్ పరిమితి'
  },
  chart_awaiting: {
    en: '🔌 Awaiting IoT Signal — Chart will appear when live data arrives.',
    hi: '🔌 IoT सिग्नल का इंतजार — लाइव डेटा आने पर चार्ट दिखेगा।',
    kn: '🔌 IoT ಸಿಗ್ನಲ್ ನಿರೀಕ್ಷೆ — ನೇರ ಡೇಟಾ ಬಂದಾಗ ಚಾರ್ಟ್ ಕಾಣಿಸಿಕೊಳ್ಳುತ್ತದೆ.',
    ta: '🔌 IoT சமிக்ஞை எதிர்பார்க்கிறது — நேரடி தரவு வந்தால் விளக்கப்படம் தோன்றும்.',
    te: '🔌 IoT సిగ్నల్ కోసం వేచి ఉంది — లైవ్ డేటా వచ్చినప్పుడు చార్ట్ కనిపిస్తుంది.'
  },
  stat_min: {
    en: 'Min', hi: 'न्यूनतम', kn: 'ಕನಿಷ್ಠ', ta: 'குறைந்தபட்சம்', te: 'కనిష్ఠం'
  },
  stat_avg: {
    en: 'Avg', hi: 'औसत', kn: 'ಸರಾಸರಿ', ta: 'சராசரி', te: 'సగటు'
  },
  stat_max: {
    en: 'Max', hi: 'अधिकतम', kn: 'ಗರಿಷ್ಠ', ta: 'அதிகபட்சம்', te: 'గరిష್ಠం'
  },
  stat_anomalies: {
    en: 'Anomalies', hi: 'विसंगतियाँ', kn: 'ವ್ಯತ್ಯಾಸಗಳು', ta: 'முரண்பாடுகள்', te: 'అసాధారణాలు'
  },

  // ─── IoT Panel ─────────────────────────────────────────────────────────────
  iot_panel_title: {
    en: 'IoT Integration', hi: 'IoT एकीकरण', kn: 'IoT ಏಕೀಕರಣ', ta: 'IoT ஒருங்கிணைப்பு', te: 'IoT ఏకీకరణ'
  },
  iot_sensor_type: {
    en: 'Sensor Type', hi: 'सेंसर प्रकार', kn: 'Sensor ಪ್ರಕಾರ', ta: 'சென்சார் வகை', te: 'సెన్సర్ రకం'
  },
  iot_unit: {
    en: 'Unit', hi: 'इकाई', kn: 'ಘಟಕ', ta: 'அலகு', te: 'యూనిట్'
  },
  iot_normal_range: {
    en: 'Normal Range', hi: 'सामान्य सीमा', kn: 'ಸಾಮಾನ್ಯ ಶ್ರೇಣಿ', ta: 'சாதாரண வரம்பு', te: 'సాధారణ పరిధి'
  },
  iot_warn_range: {
    en: 'Warning Range', hi: 'चेतावनी सीमा', kn: 'ಎಚ್ಚರಿಕೆ ಶ್ರೇಣಿ', ta: 'எச்சரிக்கை வரம்பு', te: 'హెచ్చరిక పరిధి'
  },
  iot_crit_thresh: {
    en: 'Critical Threshold', hi: 'गंभीर सीमा', kn: 'ಗಂಭೀರ ಮಿತಿ', ta: 'நெருக்கடி வரம்பு', te: 'క్రిటికల్ పరిమితి'
  },
  iot_data_feed: {
    en: 'Data Feed', hi: 'डेटा फीड', kn: 'ಡೇಟಾ ಫೀಡ್', ta: 'தரவு சுவடு', te: 'డేటా ఫీడ్'
  },
  iot_not_connected: {
    en: 'WebSocket / MQTT — not connected',
    hi: 'WebSocket / MQTT — कनेक्ट नहीं',
    kn: 'WebSocket / MQTT — ಸಂಪರ್ಕಿಲ್ಲ',
    ta: 'WebSocket / MQTT — இணைக்கப்படவில்லை',
    te: 'WebSocket / MQTT — కనెక్ట్ కాలేదు'
  },
  iot_pending: {
    en: 'Pending', hi: 'लंबित', kn: 'ಬಾಕಿ', ta: 'நிலுவையில்', te: 'పెండింగ్'
  },
  iot_awaiting_sig: {
    en: '⏳ Awaiting IoT Signal',
    hi: '⏳ IoT सिग्नल का इंतजार',
    kn: '⏳ IoT ಸಿಗ್ನಲ್ ನಿರೀಕ್ಷೆ',
    ta: '⏳ IoT சமிக்ஞை எதிர்பார்க்கிறது',
    te: '⏳ IoT సిగ్నల్ కోసం వేచి ఉంది'
  },
  iot_note: {
    en: 'Live sensor data has not been received yet. Simulated readings are disabled.',
    hi: 'लाइव सेंसर डेटा अभी तक प्राप्त नहीं हुआ। सिम्युलेटेड रीडिंग अक्षम हैं।',
    kn: 'ನೇರ sensor data ಇನ್ನೂ ಬಂದಿಲ್ಲ. ಸಿಮ್ಯುಲೇಟೆಡ್ readings ನಿಷ್ಕ್ರಿಯ.',
    ta: 'நேரடி சென்சார் தரவு இன்னும் கிடைக்கவில்லை. உருவகப்படுத்தப்பட்ட அளவீடுகள் முடக்கப்பட்டுள்ளன.',
    te: 'లైవ్ సెన్సర్ డేటా ఇంకా రాలేదు. సిమ్యులేటెడ్ రీడింగ్‌లు నిష్క్రియం.'
  },

  // ─── Alert log ─────────────────────────────────────────────────────────────
  alert_log: {
    en: 'Alert Log', hi: 'अलर्ट लॉग', kn: 'ಅಲರ್ಟ್ ಲಾಗ್', ta: 'எச்சரிக்கை பதிவு', te: 'అలర్ట్ లాగ్'
  },
  alert_clear: {
    en: 'Clear', hi: 'साफ करें', kn: 'ಅಳಿಸಿ', ta: 'அழி', te: 'క్లియర్'
  },
  alert_cleared_at: {
    en: 'Cleared at', hi: 'साफ किया', kn: 'ಅಳಿಸಲಾಗಿದೆ', ta: 'அழிக்கப்பட்டது', te: 'క్లియర్ చేయబడింది'
  },
  alert_empty: {
    en: '🔌 Awaiting IoT Signal',
    hi: '🔌 IoT सिग्नल का इंतजार',
    kn: '🔌 IoT ಸಿಗ್ನಲ್ ನಿರೀಕ್ಷೆ',
    ta: '🔌 IoT சமிக்ஞை',
    te: '🔌 IoT సిగ్నల్ కోసం వేచి ఉంది'
  },
  alert_empty_body: {
    en: 'Alert monitoring will begin when real sensor data is received.',
    hi: 'वास्तविक सेंसर डेटा मिलने पर अलर्ट मॉनिटरिंग शुरू होगी।',
    kn: 'ನೈಜ sensor data ಬಂದಾಗ Alert monitoring ಪ್ರಾರಂಭ.',
    ta: 'உண்மையான சென்சார் தரவு கிடைத்தால் எச்சரிக்கை கண்காணிப்பு தொடங்கும்.',
    te: 'నిజమైన సెన్సర్ డేటా వచ్చినప్పుడు అలర్ట్ మానిటరింగ్ ప్రారంభమవుతుంది.'
  },
  alert_confirm: {
    en: 'Confirm anomaly',
    hi: 'Anomaly की पुष्टि करें',
    kn: 'Anomaly ದೃಢಪಡಿಸಿ',
    ta: 'முரண்பாடு உறுதிப்படுத்து',
    te: 'అనామలీ నిర్ధారించు'
  },
  alert_dismiss: {
    en: 'Dismiss', hi: 'अनदेखा करें', kn: 'ವಜಾ ಮಾಡಿ', ta: 'நிராகரி', te: 'విస్మరించు'
  },

  // ─── Home page ─────────────────────────────────────────────────────────────
  normal_range: {
    en: 'Normal', hi: 'सामान्य', kn: 'ಸಾಮಾನ್ಯ', ta: 'சாதாரண', te: 'సాధారణ'
  },
  warning_range: {
    en: 'Warning', hi: 'चेतावनी', kn: 'ಎಚ್ಚರಿಕೆ', ta: 'எச்சரிக்கை', te: 'హెచ్చరిక'
  },

  // ─── Control signal banner ─────────────────────────────────────────────────
  banner_system: {
    en: 'System:', hi: 'सिस्टम:', kn: 'ಸಿಸ್ಟಮ್:', ta: 'அமைப்பு:', te: 'సిస్టమ్:'
  },
  intent_run: {
    en: '🟢 RUN', hi: '🟢 चालू', kn: '🟢 ಚಾಲು', ta: '🟢 இயக்கு', te: '🟢 నడుపు'
  },
  intent_de_rate: {
    en: '🟡 DE-RATE', hi: '🟡 गति कम', kn: '🟡 ವೇಗ ಕಡಿತ', ta: '🟡 வேகக் குறைப்பு', te: '🟡 వేగ తగ్గింపు'
  },
  intent_shutdown: {
    en: '🔴 SHUTDOWN', hi: '🔴 बंद करो', kn: '🔴 ನಿಲ್ಲಿಸು', ta: '🔴 நிறுத்து', te: '🔴 ఆపు'
  },
  banner_fail_safe: {
    en: '⚠ FAIL-SAFE ALERT',
    hi: '⚠ FAIL-SAFE चेतावनी',
    kn: '⚠ FAIL-SAFE ಎಚ್ಚರಿಕೆ',
    ta: '⚠ FAIL-SAFE எச்சரிக்கை',
    te: '⚠ FAIL-SAFE హెచ్చరిక'
  },
  banner_actuation: {
    en: '⚠ ACTUATION FAILURE',
    hi: '⚠ ACTUATION विफलता',
    kn: '⚠ ACTUATION ವೈಫಲ್ಯ',
    ta: '⚠ ACTUATION தோல்வி',
    te: '⚠ ACTUATION వైఫల్యం'
  },

  // ─── Leaderboard ───────────────────────────────────────────────────────────
  leader_title: {
    en: 'TenderWatch Leaderboard',
    hi: 'TenderWatch लीडरबोर्ड',
    kn: 'TenderWatch Leaderboard',
    ta: 'TenderWatch தரவரிசை',
    te: 'TenderWatch లీడర్‌బోర్డ్'
  },
  leader_sub: {
    en: 'Top organizations running predictive maintenance',
    hi: 'भविष्यसूचक रखरखाव चलाने वाले शीर्ष संगठन',
    kn: 'Predictive maintenance ನಡೆಸುವ ಉನ್ನತ ಸಂಸ್ಥೆಗಳು',
    ta: 'முன்கணிப்பு பராமரிப்பு நடத்தும் முன்னணி நிறுவனங்கள்',
    te: 'ప్రిడిక్టివ్ మెయింటెనెన్స్ నడుపుతున్న అగ్రగామి సంస్థలు'
  },
  leader_note: {
    en: 'Rankings based on monitored assets, uptime, and anomaly response time. Refreshes every 24 h.',
    hi: 'रैंकिंग निगरानी की गई संपत्ति, अपटाइम और anomaly प्रतिक्रिया समय पर आधारित है।',
    kn: 'Rankings ಮೇಲ್ವಿಚಾರಣೆ assets, uptime ಮತ್ತು anomaly ಪ್ರತಿಕ್ರಿಯೆ ಸಮಯವನ್ನು ಆಧರಿಸಿದೆ.',
    ta: 'தரவரிசை கண்காணிக்கப்பட்ட சொத்துக்கள், இயங்கும் நேரம் மற்றும் முரண்பாடு பதில் நேரத்தை அடிப்படையாகக் கொண்டது.',
    te: 'రాంకింగ్‌లు పర్యవేక్షించబడిన ఆస్తులు, అప్‌టైమ్ మరియు అనామలీ ప్రతిస్పందన సమయం ఆధారంగా ఉన్నాయి.'
  },
  leader_live: {
    en: 'Live', hi: 'सीधा', kn: 'ನೇರ', ta: 'நேரடி', te: 'లైవ్'
  },
  leader_col_rank: {
    en: '#', hi: 'क्र.', kn: '#', ta: '#', te: '#'
  },
  leader_col_org: {
    en: 'Organization', hi: 'संगठन', kn: 'ಸಂಸ್ಥೆ', ta: 'நிறுவனம்', te: 'సంస్థ'
  },
  leader_col_sector: {
    en: 'Sector', hi: 'क्षेत्र', kn: 'ಕ್ಷೇತ್ರ', ta: 'துறை', te: 'రంగం'
  },
  leader_col_score: {
    en: 'Health Score', hi: 'स्वास्थ्य स्कोर', kn: 'ಆರೋಗ್ಯ ಸ್ಕೋರ್', ta: 'ஆரோக்கிய மதிப்பெண்', te: 'ఆరోగ్య స్కోర్'
  },
  leader_col_uptime: {
    en: 'Uptime %', hi: 'अपटाइम %', kn: 'Uptime %', ta: 'இயக்க நேரம் %', te: 'అప్‌టైమ్ %'
  },
  leader_col_mtbf: {
    en: 'MTBF (h)', hi: 'MTBF (घं.)', kn: 'MTBF (ಗಂ.)', ta: 'MTBF (மணி)', te: 'MTBF (గం.)'
  },
  leader_col_resp: {
    en: 'Response', hi: 'प्रतिक्रिया', kn: 'ಪ್ರತಿಕ್ರಿಯೆ', ta: 'பதில் நேரம்', te: 'ప్రతిస్పందన'
  },
  leader_col_trend: {
    en: 'Trend', hi: 'रुझान', kn: 'ಟ್ರೆಂಡ್', ta: 'போக்கு', te: 'ట్రెండ్'
  },
  trend_improving: {
    en: 'Improving', hi: 'सुधार', kn: 'ಸುಧಾರಿಸುತ್ತಿದೆ', ta: 'மேம்படுகிறது', te: 'మెరుగుపడుతోంది'
  },
  trend_declining: {
    en: 'Declining', hi: 'गिरावट', kn: 'ಕುಸಿಯುತ್ತಿದೆ', ta: 'குறைகிறது', te: 'తగ్గుతోంది'
  },
  trend_stable: {
    en: 'Stable', hi: 'स्थिर', kn: 'ಸ್ಥಿರ', ta: 'நிலையானது', te: 'స్థిరంగా ఉంది'
  },
  leader_std_score: {
    en: '📐 Health Score: ISO 55000 composite',
    hi: '📐 स्वास्थ्य स्कोर: ISO 55000 composite',
    kn: '📐 ಆರೋಗ್ಯ ಸ್ಕೋರ್: ISO 55000',
    ta: '📐 ஆரோக்கிய மதிப்பெண்: ISO 55000',
    te: '📐 ఆరోగ్య స్కోర్: ISO 55000'
  },
  leader_std_uptime: {
    en: '⏱️ Uptime: ISO 22400-2 OEE Availability',
    hi: '⏱️ अपटाइम: ISO 22400-2 OEE उपलब्धता',
    kn: '⏱️ Uptime: ISO 22400-2 OEE',
    ta: '⏱️ இயக்க நேரம்: ISO 22400-2 OEE',
    te: '⏱️ అప్‌టైమ్: ISO 22400-2 OEE'
  },
  leader_std_mtbf: {
    en: '🔧 MTBF: ISO 14224',
    hi: '🔧 MTBF: ISO 14224',
    kn: '🔧 MTBF: ISO 14224',
    ta: '🔧 MTBF: ISO 14224',
    te: '🔧 MTBF: ISO 14224'
  },
  leader_std_resp: {
    en: '⚡ Response: IIoT anomaly-to-action latency',
    hi: '⚡ प्रतिक्रिया: IIoT anomaly-to-action विलंब',
    kn: '⚡ ಪ್ರತಿಕ್ರಿಯೆ: IIoT anomaly-to-action latency',
    ta: '⚡ பதில் நேரம்: IIoT anomaly-to-action தாமதம்',
    te: '⚡ ప్రతిస్పందన: IIoT అనామలీ-నుండి-చర్య వ్యవధి'
  },

  // ─── Explorer history ──────────────────────────────────────────────────────
  explorer_history: {
    en: 'History', hi: 'इतिहास', kn: 'ಇತಿಹಾಸ', ta: 'வரலாறு', te: 'చరిత్ర'
  },
  explorer_refresh: {
    en: 'Refresh', hi: 'ताज़ा करें', kn: 'ರಿಫ್ರೆಶ್', ta: 'புதுப்பಿ', te: 'రీఫ్రెష్'
  },
  explorer_loading: {
    en: 'Loading…', hi: 'लोड हो रहा है…', kn: 'ಲೋಡ್ ಆಗುತ್ತಿದೆ…', ta: 'ஏற்றுகிறது…', te: 'లోడ్ అవుతోంది…'
  },
  explorer_no_history: {
    en: 'No history yet.',
    hi: 'अभी कोई इतिहास नहीं।',
    kn: 'ಇನ್ನೂ ಯಾವ ಇತಿಹಾಸವಿಲ್ಲ.',
    ta: 'இன்னும் வரலாறு இல்லை.',
    te: 'ఇంకా చరిత్ర లేదు.'
  },
  explorer_replay: {
    en: '↩ Replay', hi: '↩ दोहराएं', kn: '↩ ಮರುಪ್ಲೇ', ta: '↩ மீண்டும் இயக்கு', te: '↩ రీప్లే'
  },
  explorer_replay_title: {
    en: 'Replay this workspace state',
    hi: 'इस workspace स्थिति को दोहराएं',
    kn: 'ಈ workspace ಸ್ಥಿತಿಯನ್ನು ಮರುಪ್ಲೇ ಮಾಡಿ',
    ta: 'இந்த workspace நிலையை மீண்டும் இயக்கு',
    te: 'ఈ workspace స్థితిని రీప్లే చేయండి'
  },

  // ─── ML Status Panel ───────────────────────────────────────────────────────
  ml_title: {
    en: '🧠 Adaptive ML Engine',
    hi: '🧠 अनुकूली ML Engine',
    kn: '🧠 ಅಳವಡಿಕೆ ML Engine',
    ta: '🧠 தகவமைக்கும் ML Engine',
    te: '🧠 అడాప్టివ్ ML ఇంజిన్'
  },
  ml_subtitle: {
    en: 'Learning from observed readings.',
    hi: 'देखी गई रीडिंग से सीख रहा है।',
    kn: 'ಗಮನಿಸಿದ readings ನಿಂದ ಕಲಿಯುತ್ತಿದೆ.',
    ta: 'கவனிக்கப்பட்ட அளவீடுகளிலிருந்து கற்கிறது.',
    te: 'గమనించిన రీడింగ్‌ల నుండి నేర్చుకుంటోంది.'
  },
  ml_conf: {
    en: 'Confidence', hi: 'विश्वास', kn: 'ವಿಶ್ವಾಸ', ta: 'நம்பிக்கை', te: 'నమ్మకం'
  },
  ml_accuracy: {
    en: 'Accuracy', hi: 'सटीकता', kn: 'ನಿಖರತೆ', ta: 'துல்லியம்', te: 'ఖచ్చితత'
  },
  ml_readings: {
    en: 'Samples', hi: 'नमूने', kn: 'ಮಾದರಿಗಳು', ta: 'மாதிரிகள்', te: 'నమూనాలు'
  },
  ml_score: {
    en: 'Anomaly Score', hi: 'Anomaly स्कोर', kn: 'Anomaly ಸ್ಕೋರ್', ta: 'முரண்பாடு மதிப்பெண்', te: 'అనామలీ స్కోర్'
  },
  ml_learned: {
    en: 'Learned Band', hi: 'सीखी हुई सीमा', kn: 'ಕಲಿತ ಶ್ರೇಣಿ', ta: 'கற்ற வரம்பு', te: 'నేర్చుకున్న పరిధి'
  },
  ml_awaiting: {
    en: 'Awaiting data…', hi: 'डेटा का इंतजार…', kn: 'ಡೇಟಾ ನಿರೀಕ್ಷೆ…', ta: 'தரவு எதிர்பார்க்கிறது…', te: 'డేటా కోసం వేచి ఉంది…'
  },
  ml_cold: {
    en: 'Cold start — connect IoT to begin learning',
    hi: 'Cold start — सीखना शुरू करने के लिए IoT कनेक्ट करें',
    kn: 'Cold start — ಕಲಿಕೆ ಪ್ರಾರಂಭಿಸಲು IoT ಸಂಪರ್ಕಿಸಿ',
    ta: 'Cold start — கற்கல் தொடங்க IoT இணைக்கவும்',
    te: 'Cold start — నేర్చుకోవడం ప్రారంభించడానికి IoT కనెక్ట్ చేయండి'
  },
  ml_version: {
    en: 'Model version', hi: 'Model संस्करण', kn: 'Model ಆವೃತ್ತಿ', ta: 'மாதிரி பதிப்பு', te: 'మోడల్ వెర్షన్'
  },
  ml_recalib: {
    en: 'Last recalibration',
    hi: 'अंतिम पुन:अंशांकन',
    kn: 'ಕೊನೆಯ ಮರು ಕ್ಯಾಲಿಬ್ರೇಶನ್',
    ta: 'கடந்த மீண்டும் அளவிடல்',
    te: 'చివరి రీకాలిబ్రేషన్'
  },
  ml_trend: {
    en: 'Accuracy trend',
    hi: 'सटीकता रुझान',
    kn: 'ನಿಖರತೆ ಟ್ರೆಂಡ್',
    ta: 'துல்லிய போக்கு',
    te: 'ఖచ్చితత ట్రెండ్'
  },

  // ─── About / FAQ page ──────────────────────────────────────────────────────
  about_title: {
    en: 'About IntelliWatch',
    hi: 'IntelliWatch के बारे में',
    kn: 'IntelliWatch ಬಗ್ಗೆ',
    ta: 'IntelliWatch பற்றி',
    te: 'IntelliWatch గురించి'
  },

  // ─── Login page ─────────────────────────────────────────────────────────────
  login_title: {
    en: 'IntelliWatch',
    hi: 'IntelliWatch',
    kn: 'IntelliWatch',
    ta: 'IntelliWatch',
    te: 'IntelliWatch'
  },
  login_sub: {
    en: 'Anomaly Detection & Decision Support',
    hi: 'Anomaly Detection और Decision Support',
    kn: 'Anomaly Detection ಮತ್ತು Decision Support',
    ta: 'முரண்பாடு கண்டறிதல் மற்றும் முடிவு ஆதரவு',
    te: 'అనామలీ డిటెక్షన్ మరియు నిర్ణయ మద్దతు'
  },
  mode_operator_title: {
    en: 'Operator / Engineer',
    hi: 'ऑपरेटर / इंजीनियर',
    kn: 'ಆಪರೇಟರ್ / ಇಂಜಿನಿಯರ್',
    ta: 'இயக்குனர் / பொறியாளர்',
    te: 'ఆపరేటర్ / ఇంజినీర్'
  },
  mode_operator_sub: {
    en: 'Monitor, analyse & maintain',
    hi: 'निगरानी, विश्लेषण और रखरखाव',
    kn: 'ಮೇಲ್ವಿಚಾರಣೆ, ವಿಶ್ಲೇಷಣೆ ಮತ್ತು ನಿರ್ವಹಣೆ',
    ta: 'கண்காணி, பகுப்பாய் மற்றும் பராமரி',
    te: 'పర్యవేక్షించు, విశ్లేషించు & నిర్వహించు'
  },
  mode_admin_title: {
    en: 'Administrator',
    hi: 'प्रशासक',
    kn: 'ನಿರ್ವಾಹಕ',
    ta: 'நிர்வாகி',
    te: 'నిర్వాహకుడు'
  },
  mode_admin_sub: {
    en: 'Full system access',
    hi: 'पूरी सिस्टम पहुँच',
    kn: 'ಸಂಪೂರ್ಣ ಸಿಸ್ಟಮ್ ಪ್ರವೇಶ',
    ta: 'முழு அமைப்பு அணுகல்',
    te: 'పూర్తి సిస్టమ్ యాక్సెస్'
  },
  sign_in_workspace: {
    en: 'Sign in to your workspace',
    hi: 'अपने workspace में साइन इन करें',
    kn: 'ನಿಮ್ಮ workspace ಗೆ ಸೈನ್ ಇನ್ ಮಾಡಿ',
    ta: 'உங்கள் workspace இல் உள்நுழைக',
    te: 'మీ workspace లో సైన్ ఇన్ చేయండి'
  },
  sign_in_admin: {
    en: 'Sign in with administrator credentials',
    hi: 'प्रशासक क्रेडेंशियल से साइन इन करें',
    kn: 'ನಿರ್ವಾಹಕ credentials ನಿಂದ ಸೈನ್ ಇನ್ ಮಾಡಿ',
    ta: 'நிர்வாகி சான்றுகளுடன் உள்நுழைக',
    te: 'నిర్వాహకుడు credentials తో సైన్ ఇన్ చేయండి'
  },
  role_op_label: {
    en: 'Operator', hi: 'ऑपरेटर', kn: 'ಆಪರೇಟರ್', ta: 'இயக்குனர்', te: 'ఆపరేటర్'
  },
  role_op_hint: {
    en: 'Monitor & analyse',
    hi: 'निगरानी और विश्लेषण',
    kn: 'ಮೇಲ್ವಿಚಾರಣೆ ಮತ್ತು ವಿಶ್ಲೇಷಣೆ',
    ta: 'கண்காணி மற்றும் பகுப்பாய்',
    te: 'పర్యవేక్షించు & విశ్లేషించు'
  },
  role_eng_label: {
    en: 'Engineer', hi: 'इंजीनियर', kn: 'ಇಂಜಿನಿಯರ್', ta: 'பொறியாளர்', te: 'ఇంజినీర్'
  },
  role_eng_hint: {
    en: 'Maintenance & control',
    hi: 'रखरखाव और नियंत्रण',
    kn: 'ನಿರ್ವಹಣೆ ಮತ್ತು ನಿಯಂತ್ರಣ',
    ta: 'பராமரிப்பு மற்றும் கட்டுப்பாடு',
    te: 'నిర్వహణ & నియంత్రణ'
  },
  forgot_password: {
    en: 'Forgot password?',
    hi: 'पासवर्ड भूल गए?',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿದ್ದೀರಾ?',
    ta: 'கடவுச்சொல் மறந்துவிட்டதா?',
    te: 'పాస్‌వర్డ్ మర్చిపోయారా?'
  },
  register_link: {
    en: 'Register', hi: 'पंजीकरण', kn: 'ನೋಂದಣಿ', ta: 'பதிவு செய்', te: 'నమోదు చేయండి'
  },
  register_as_admin: {
    en: '🛡️ Register as Admin',
    hi: '🛡️ Admin के रूप में पंजीकरण',
    kn: '🛡️ Admin ಆಗಿ ನೋಂದಣಿ',
    ta: '🛡️ Admin ஆக பதிவு செய்',
    te: '🛡️ Admin గా నమోదు చేయండి'
  },
  offline_hint_full: {
    en: 'Offline demo: username',
    hi: 'ऑफलाइन डेमो: username',
    kn: 'ಆಫ್‌ಲೈನ್ ಡೆಮೊ: username',
    ta: 'ஆஃப்லைன் டெமோ: username',
    te: 'ఆఫ్‌లైన్ డెమో: username'
  },
  offline_hint_pw: {
    en: '/ password', hi: '/ password', kn: '/ password', ta: '/ password', te: '/ password'
  },
  lbl_username: {
    en: 'Username', hi: 'उपयोगकर्ता नाम', kn: 'ಬಳಕೆದಾರ ಹೆಸರು', ta: 'பயனர் பெயர்', te: 'వినియోగదారు పేరు'
  },
  lbl_password: {
    en: 'Password', hi: 'पासवर्ड', kn: 'ಪಾಸ್‌ವರ್ಡ್', ta: 'கடவுச்சொல்', te: 'పాస్‌వర్డ్'
  },
  lbl_full_name: {
    en: 'Full Name', hi: 'पूरा नाम', kn: 'ಪೂರ್ಣ ಹೆಸರು', ta: 'முழு பெயர்', te: 'పూర్తి పేరు'
  },
  lbl_confirm_pw: {
    en: 'Confirm Password',
    hi: 'पासवर्ड पुष्टि करें',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ದೃಢಪಡಿಸಿ',
    ta: 'கடவுச்சொல் உறுதிப்படுத்து',
    te: 'పాస్‌వర్డ్ నిర్ధారించండి'
  },
  lbl_invite_token: {
    en: 'Admin Invite Token',
    hi: 'Admin आमंत्रण टोकन',
    kn: 'Admin ಆಮಂತ್ರಣ ಟೋಕನ್',
    ta: 'Admin அழைப்பு டோக்கன்',
    te: 'Admin ఆహ్వాన టోకెన్'
  },
  lbl_invite_code: {
    en: 'Invite Code',
    hi: 'आमंत्रण कोड',
    kn: 'ಆಮಂತ್ರಣ ಕೋಡ್',
    ta: 'அழைப்பு குறியீடு',
    te: 'ఆహ్వాన కోడ్'
  },
  lbl_from_admin: {
    en: 'from admin', hi: 'admin से', kn: 'admin ನಿಂದ', ta: 'admin இலிருந்து', te: 'admin నుండి'
  },
  lbl_role: {
    en: 'Role', hi: 'भूमिका', kn: 'ಪಾತ್ರ', ta: 'பங்கு', te: 'పాత్ర'
  },
  lbl_reset_token: {
    en: 'Reset Token', hi: 'रीसेट टोकन', kn: 'ರೀಸೆಟ್ ಟೋಕನ್', ta: 'மீட்டமை டோக்கன்', te: 'రీసెట్ టోకెన్'
  },
  lbl_new_password: {
    en: 'New Password', hi: 'नया पासवर्ड', kn: 'ಹೊಸ ಪಾಸ್‌ವರ್ಡ್', ta: 'புதிய கடவுச்சொல்', te: 'కొత్త పాస్‌వర్డ్'
  },
  ph_username: {
    en: 'Enter your username',
    hi: 'उपयोगकर्ता नाम दर्ज करें',
    kn: 'ಬಳಕೆದಾರ ಹೆಸರು ನಮೂದಿಸಿ',
    ta: 'பயனர் பெயரை உள்ளிடுக',
    te: 'వినియోగదారు పేరు నమోదు చేయండి'
  },
  ph_password: {
    en: 'Enter your password',
    hi: 'पासवर्ड दर्ज करें',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ನಮೂದಿಸಿ',
    ta: 'கடவுச்சொல்லை உள்ளிடுக',
    te: 'పాస్‌వర్డ్ నమోదు చేయండి'
  },
  ph_choose_username: {
    en: 'Choose username',
    hi: 'उपयोगकर्ता नाम चुनें',
    kn: 'ಬಳಕೆದಾರ ಹೆಸರು ಆರಿಸಿ',
    ta: 'பயனர் பெயர் தேர்வு செய்',
    te: 'వినియోగదారు పేరు ఎంచుకోండి'
  },
  ph_your_name: {
    en: 'Your full name',
    hi: 'आपका पूरा नाम',
    kn: 'ನಿಮ್ಮ ಪೂರ್ಣ ಹೆಸರು',
    ta: 'உங்கள் முழு பெயர்',
    te: 'మీ పూర్తి పేరు'
  },
  ph_strong_password: {
    en: 'Strong password',
    hi: 'मजबूत पासवर्ड',
    kn: 'ಶಕ್ತಿಶಾಲಿ ಪಾಸ್‌ವರ್ಡ್',
    ta: 'வலுவான கடவுச்சொல்',
    te: 'బలమైన పాస్‌వర్డ్'
  },
  ph_repeat_password: {
    en: 'Repeat password',
    hi: 'पासवर्ड दोबारा दर्ज करें',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ಮರು ನಮೂದಿಸಿ',
    ta: 'கடவுச்சொல்லை மீண்டும் உள்ளிடுக',
    te: 'పాస్‌వರ್ಡ్ మళ్ళీ నమోదు చేయండి'
  },
  ph_paste_token: {
    en: 'Paste token from admin',
    hi: 'Admin का टोकन पेस्ट करें',
    kn: 'Admin ಟೋಕನ್ ಅಂಟಿಸಿ',
    ta: 'Admin டோக்கனை ஒட்டு',
    te: 'Admin టోకెన్ పేస్ట్ చేయండి'
  },
  ph_invite_code: {
    en: 'Admin invite code',
    hi: 'Admin आमंत्रण कोड',
    kn: 'Admin ಆಮಂತ್ರಣ ಕೋಡ್',
    ta: 'Admin அழைப்பு குறியீடு',
    te: 'Admin ఆహ్వాన కోడ్'
  },
  ph_paste_reset_token: {
    en: 'Paste token',
    hi: 'टोकन पेस्ट करें',
    kn: 'ಟೋಕನ್ ಅಂಟಿಸಿ',
    ta: 'டோக்கனை ஒட்டு',
    te: 'టోకెన్ పేస్ట్ చేయండి'
  },
  ph_new_password: {
    en: 'New password (min 12)',
    hi: 'नया पासवर्ड (न्यूनतम 12)',
    kn: 'ಹೊಸ ಪಾಸ್‌ವರ್ಡ್ (ಕನಿಷ್ಠ 12)',
    ta: 'புதிய கடவுச்சொல் (குறைந்தபட்சம் 12)',
    te: 'కొత్త పాస్‌వర్డ్ (కనిష్ఠం 12)'
  },
  pw_min_hint: {
    en: 'min 12 chars',
    hi: 'न्यूनतम 12 अक्षर',
    kn: 'ಕನಿಷ್ಠ 12 ಅಕ್ಷರ',
    ta: 'குறைந்தபட்சம் 12 எழுத்துகள்',
    te: 'కనిష్ఠం 12 అక్షరాలు'
  },
  pw_mismatch: {
    en: 'Passwords do not match',
    hi: 'पासवर्ड मेल नहीं खाते',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ಹೊಂದಾಣಿಕೆಯಾಗುತ್ತಿಲ್ಲ',
    ta: 'கடவுச்சொற்கள் பொருந்தவில்லை',
    te: 'పాస్‌వర్డ్‌లు సరిపోలలేదు'
  },
  err_all_required: {
    en: 'All fields are required.',
    hi: 'सभी फ़ील्ड आवश्यक हैं।',
    kn: 'ಎಲ್ಲ ಕ್ಷೇತ್ರಗಳು ಅಗತ್ಯ.',
    ta: 'அனைத்து புலங்களும் தேவை.',
    te: 'అన్ని ఫీల్డ్‌లూ అవసరం.'
  },
  err_pw_short: {
    en: 'Password must be at least 12 characters.',
    hi: 'पासवर्ड कम से कम 12 अक्षर होना चाहिए।',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ಕನಿಷ್ಠ 12 ಅಕ್ಷರಗಳಿರಬೇಕು.',
    ta: 'கடவுச்சொல் குறைந்தது 12 எழுத்துகள் இருக்க வேண்டும்.',
    te: 'పాస్‌వర్డ్ కనిష్ఠం 12 అక్షరాలు ఉండాలి.'
  },
  err_reg_failed: {
    en: 'Registration failed.',
    hi: 'पंजीकरण विफल।',
    kn: 'ನೋಂದಣಿ ವಿಫಲ.',
    ta: 'பதிவு தோல்வியடைந்தது.',
    te: 'నమోదు విఫలమైంది.'
  },
  err_reset_failed: {
    en: 'Reset failed.',
    hi: 'रीसेट विफल।',
    kn: 'ರೀಸೆಟ್ ವಿಫಲ.',
    ta: 'மீட்டமைவு தோல்வியடைந்தது.',
    te: 'రీసెట్ విఫలమైంది.'
  },
  err_network: {
    en: 'Network error — cannot reach the server.',
    hi: 'नेटवर्क त्रुटि — सर्वर तक नहीं पहुँचा।',
    kn: 'ನೆಟ್‌ವರ್ಕ್ ದೋಷ — ಸರ್ವರ್ ತಲುಪಲು ಸಾಧ್ಯವಿಲ್ಲ.',
    ta: 'நெட்வொர்க் பிழை — சர்வர் கிடைக்கவில்லை.',
    te: 'నెట్‌వర్క్ లోపం — సర్వర్ చేరుకోలేకపోయింది.'
  },
  err_username_required: {
    en: 'Enter your username.',
    hi: 'उपयोगकर्ता नाम दर्ज करें।',
    kn: 'ಬಳಕೆದಾರ ಹೆಸರು ನಮೂದಿಸಿ.',
    ta: 'பயனர் பெயரை உள்ளிடவும்.',
    te: 'వినియోగదారు పేరు నమోదు చేయండి.'
  },
  err_token_required: {
    en: 'Enter the reset token.',
    hi: 'रीसेट टोकन दर्ज करें।',
    kn: 'ರೀಸೆಟ್ ಟೋಕನ್ ನಮೂದಿಸಿ.',
    ta: 'மீட்டமை டோக்கனை உள்ளிடவும்.',
    te: 'రీసెట్ టోకెన్ నమోదు చేయండి.'
  },
  modal_admin_reg_title: {
    en: '🛡️ Admin Account Registration',
    hi: '🛡️ Admin खाता पंजीकरण',
    kn: '🛡️ Admin ಖಾತೆ ನೋಂದಣಿ',
    ta: '🛡️ Admin கணக்கு பதிவு',
    te: '🛡️ Admin ఖాతా నమోదు'
  },
  modal_admin_reg_notice: {
    en: '🔑 Requires a one-time invite token generated by an existing administrator.',
    hi: '🔑 मौजूदा प्रशासक द्वारा जनरेट किए गए एकल-उपयोग आमंत्रण टोकन की आवश्यकता है।',
    kn: '🔑 ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ ನಿರ್ವಾಹಕರಿಂದ ಒಂದು-ಬಾರಿ ಆಮಂತ್ರಣ ಟೋಕನ್ ಅಗತ್ಯ.',
    ta: '🔑 ஒரு முறை மட்டும் பயன்படுத்தக்கூடிய அழைப்பு டோக்கன் தேவை.',
    te: '🔑 ఒక్కసారి వినియోగించే ఆహ్వాన టోకెన్ అవసరం.'
  },
  modal_token_hint: {
    en: 'Generated by an existing admin from the User Management page. Valid for 24 h, single use.',
    hi: 'User Management पेज से मौजूदा admin द्वारा जनरेट। 24 घंटे के लिए वैध, एकल उपयोग।',
    kn: 'User Management ಪುಟದಿಂದ ಅಸ್ತಿತ್ವದಲ್ಲಿರುವ admin ಜನರೇಟ್ ಮಾಡಿದ್ದಾರೆ. 24 ಗಂ ಮಾನ್ಯ.',
    ta: 'User Management பக்கத்தில் admin உருவாக்கியது. 24 மணி நேரம் செல்லுபடியாகும்.',
    te: 'User Management పేజీ నుండి admin జనరేట్ చేసారు. 24 గం పాటు చెల్లుబాటు.'
  },
  admin_created: {
    en: 'Admin account created! Invited by',
    hi: 'Admin खाता बनाया! आमंत्रित:',
    kn: 'Admin ಖಾತೆ ರಚಿಸಲಾಗಿದೆ! ಆಮಂತ್ರಿತ:',
    ta: 'Admin கணக்கு உருவாக்கப்பட்டது! அழைக்கப்பட்டவர்:',
    te: 'Admin ఖాతా సృష్టించబడింది! ఆహ్వానించబడినవారు:'
  },
  admin_created_sub: {
    en: 'You can now sign in using your credentials.',
    hi: 'आप अब अपने क्रेडेंशियल से साइन इन कर सकते हैं।',
    kn: 'ನೀವು ಈಗ credentials ನಿಂದ ಸೈನ್ ಇನ್ ಮಾಡಬಹುದು.',
    ta: 'இப்போது உங்கள் சான்றுகளுடன் உள்நுழையலாம்.',
    te: 'ఇప్పుడు మీ credentials తో సైన్ இன் చేయవచ్చు.'
  },
  btn_done: {
    en: 'Done', hi: 'हो गया', kn: 'ಮುಗಿಯಿತು', ta: 'முடிந்தது', te: 'పూర్తయింది'
  },
  btn_create_admin: {
    en: '🛡️ Create Admin Account',
    hi: '🛡️ Admin खाता बनाएं',
    kn: '🛡️ Admin ಖಾತೆ ರಚಿಸಿ',
    ta: '🛡️ Admin கணக்கு உருவாக்கு',
    te: '🛡️ Admin ఖాతా సృష్టించు'
  },
  btn_create_account: {
    en: '📝 Create Account',
    hi: '📝 खाता बनाएं',
    kn: '📝 ಖಾತೆ ರಚಿಸಿ',
    ta: '📝 கணக்கு உருவாக்கு',
    te: '📝 ఖాతా సృష్టించు'
  },
  modal_reset_title: {
    en: '🔐 Reset Password',
    hi: '🔐 पासवर्ड रीसेट',
    kn: '🔐 ಪಾಸ್‌ವರ್ಡ್ ರೀಸೆಟ್',
    ta: '🔐 கடவுச்சொல் மீட்டமை',
    te: '🔐 పాస్‌వర్డ్ రీసెట్'
  },
  modal_register_title: {
    en: '✏️ Create Account',
    hi: '✏️ खाता बनाएं',
    kn: '✏️ ಖಾತೆ ರಚಿಸಿ',
    ta: '✏️ கணக்கு உருவாக்கு',
    te: '✏️ ఖాతా సృష్టించు'
  },
  pw_updated: {
    en: 'Password updated! You can now sign in.',
    hi: 'पासवर्ड अपडेट किया! अब साइन इन कर सकते हैं।',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ಅಪ್ಡೇಟ್ ಆಗಿದೆ!',
    ta: 'கடவுச்சொல் புதுப்பிக்கப்பட்டது!',
    te: 'పాస్‌వర్డ్ అప్‌డేట్ అయింది!'
  },
  acct_created: {
    en: 'Account created! You can now sign in.',
    hi: 'खाता बनाया! अब साइन इन करें।',
    kn: 'ಖಾತೆ ರಚಿಸಲಾಗಿದೆ! ಈಗ ಸೈನ್ ಇನ್ ಮಾಡಿ.',
    ta: 'கணக்கு உருவாக்கப்பட்டது!',
    te: 'ఖాతా సృష్టించబడింది!'
  },
  fp_desc: {
    en: 'Enter your username to generate a reset token.',
    hi: 'रीसेट टोकन जनरेट करने के लिए username दर्ज करें।',
    kn: 'ರೀಸೆಟ್ ಟೋಕನ್ ಜನರೇಟ್ ಮಾಡಲು username ನಮೂದಿಸಿ.',
    ta: 'மீட்டமை டோக்கன் உருவாக்க பயனர் பெயரை உள்ளிடுக.',
    te: 'రీసెట్ టోకెన్ జనరేట్ చేయడానికి వినియోగదారు పేరు నమోదు చేయండి.'
  },
  btn_get_token: {
    en: 'Get Reset Token',
    hi: 'रीसेट टोकन प्राप्त करें',
    kn: 'ರೀಸೆಟ್ ಟೋಕನ್ ಪಡೆಯಿರಿ',
    ta: 'மீட்டமை டோக்கன் பெறு',
    te: 'రీసెట్ టోకెన్ పొందండి'
  },
  btn_set_password: {
    en: '🔒 Set New Password',
    hi: '🔒 नया पासवर्ड सेट करें',
    kn: '🔒 ಹೊಸ ಪಾಸ್‌ವರ್ಡ್ ಹೊಂದಿಸಿ',
    ta: '🔒 புதிய கடவுச்சொல் அமை',
    te: '🔒 కొత్త పాస్‌వర్డ్ సెట్ చేయండి'
  },
  btn_sign_in: {
    en: '→ Sign In',
    hi: '→ साइन इन',
    kn: '→ ಸೈನ್ ಇನ್',
    ta: '→ உள்நுழை',
    te: '→ సైన్ ಇನ್'
  },
  btn_sign_in_again: {
    en: 'Sign In',
    hi: 'साइन इन',
    kn: 'ಸೈನ್ ಇನ್',
    ta: 'உள்நுழை',
    te: 'సైన్ ఇన్'
  },
  pw_strength_label: {
    en: 'Password strength',
    hi: 'पासवर्ड शक्ति',
    kn: 'ಪಾಸ್‌ವರ್ಡ್ ಶಕ್ತಿ',
    ta: 'கடவுச்சொல் வலிமை',
    te: 'పాస్‌వర్డ్ బలం'
  },
  pw_very_weak: {
    en: 'Very Weak', hi: 'बहुत कमजोर', kn: 'ತುಂಬಾ ದುರ್ಬಲ', ta: 'மிகவும் பலவீனம்', te: 'చాలా బలహీనం'
  },
  pw_weak: {
    en: 'Weak', hi: 'कमजोर', kn: 'ದುರ್ಬಲ', ta: 'பலவீனம்', te: 'బలహీనం'
  },
  pw_fair: {
    en: 'Fair', hi: 'ठीक', kn: 'ಸಾಧಾರಣ', ta: 'நடுத்தரம்', te: 'సాధారణం'
  },
  pw_strong: {
    en: 'Strong', hi: 'मजबूत', kn: 'ಶಕ್ತಿಶಾಲಿ', ta: 'வலுவானது', te: 'బలమైనది'
  },
  pw_very_strong: {
    en: 'Very Strong',
    hi: 'बहुत मजबूत',
    kn: 'ತುಂಬಾ ಶಕ್ತಿಶಾಲಿ',
    ta: 'மிகவும் வலுவானது',
    te: 'చాలా బలమైనది'
  },

  // ─── ControlSignalBanner ───────────────────────────────────────────────────
  banner_system_label: {
    en: 'System:', hi: 'सिस्टम:', kn: 'ಸಿಸ್ಟಮ್:', ta: 'அமைப்பு:', te: 'సిస్టమ్:'
  },

  // ─── ExplorerHistory ───────────────────────────────────────────────────────
  hist_title: {
    en: 'History', hi: 'इतिहास', kn: 'ಇತಿಹಾಸ', ta: 'வரலாறு', te: 'చరిత్ర'
  },
  hist_refresh: {
    en: 'Refresh', hi: 'ताज़ा करें', kn: 'ರಿಫ್ರೆಶ್', ta: 'புதுப்பி', te: 'రీఫ్రెష్'
  },
  hist_loading: {
    en: 'Loading…', hi: 'लोड हो रहा है…', kn: 'ಲೋಡ್ ಆಗುತ್ತಿದೆ…', ta: 'ஏற்றுகிறது…', te: 'లోడ్ అవుతోంది…'
  },
  hist_empty: {
    en: 'No history yet.',
    hi: 'अभी कोई इतिहास नहीं।',
    kn: 'ಇನ್ನೂ ಇತಿಹಾಸ ಇಲ್ಲ.',
    ta: 'இன்னும் வரலாறு இல்லை.',
    te: 'ఇంకా చరిత్ర లేదు.'
  },
  hist_replay: {
    en: '↩ Replay', hi: '↩ दोहराएं', kn: '↩ ಮರುಪ್ಲೇ', ta: '↩ மீண்டும் இயக்கு', te: '↩ రీప్లే'
  },
  hist_replay_title: {
    en: 'Replay this workspace state',
    hi: 'इस workspace स्थिति को दोहराएं',
    kn: 'ಈ workspace ಸ್ಥಿತಿಯನ್ನು ಮರುಪ್ಲೇ ಮಾಡಿ',
    ta: 'இந்த workspace நிலையை மீண்டும் இயக்கு',
    te: 'ఈ workspace స్థితిని రీప్లే చేయండి'
  },
  https_secure: {
    en: 'HTTPS connection',
    hi: 'HTTPS कनेक्शन',
    kn: 'HTTPS ಸಂಪರ್ಕ',
    ta: 'HTTPS இணைப்பு',
    te: 'HTTPS కనెక్షన్'
  },

  // ─── SensorExplorer (3D Lab) ──────────────────────────────────────────────
  explorer_show_history: {
    en: 'Show History', hi: 'इतिहास दिखाएं', kn: 'ಇತಿಹಾಸ ತೋರಿಸಿ', ta: 'வரலாற்றைக் காட்டு', te: 'చరిత్ర చూపు'
  },
  explorer_hide_history: {
    en: 'Hide History', hi: 'इतिहास छुपाएं', kn: 'ಇತಿಹಾಸ ಮರೆಮಾಡಿ', ta: 'வரலாற்றை மறை', te: 'చరిత్ర దాచు'
  },
  explorer_move: {
    en: '↔ Move', hi: '↔ खिसकाएं', kn: '↔ ಸ್ಥಳಾಂತರ', ta: '↔ நகர்த்து', te: '↔ తరలించు'
  },
  explorer_cancel_move: {
    en: 'Cancel Move', hi: 'स्थानांतर रद्द करें', kn: 'ಸ್ಥಳಾಂತರ ರದ್ದು', ta: 'நகர்த்தலை ரத்து', te: 'తరలింపు రద్దు'
  },
  explorer_clear_confirm: {
    en: 'Clear all components from the workspace?',
    hi: 'workspace से सभी घटक हटाएं?',
    kn: 'workspace ನಿಂದ ಎಲ್ಲ ಘಟಕಗಳನ್ನು ತೆಗೆಯಬೇಕೆ?',
    ta: 'அனைத்து கூறுகளையும் அகற்றவா?',
    te: 'అన్ని భాగాలను తీసివేయాలా?'
  },
  explorer_fs_enter: {
    en: 'Fullscreen (F11)', hi: 'फुलस्क्रीन (F11)', kn: 'ಪೂರ್ಣಪರದೆ (F11)', ta: 'முழுத்திரை (F11)', te: 'పూర్ణస్క్రీన్ (F11)'
  },
  explorer_fs_exit: {
    en: 'Exit fullscreen',
    hi: 'फुलस्क्रीन से बाहर',
    kn: 'ಪೂರ್ಣಪರದೆ ನಿರ್ಗಮ',
    ta: 'முழுத்திரையிலிருந்து வெளி',
    te: 'పూర్ణస్క్రీన్ నుండి నిష్క్రమణ'
  },
  explorer_sel_hardware: {
    en: 'SELECTED HARDWARE',
    hi: 'चयनित हार्डवेयर',
    kn: 'ಆಯ್ದ ಹಾರ್ಡ್‌ವೇರ್',
    ta: 'தேர்ந்தெடுத்த வன்பொருள்',
    te: 'ఎంచుకున్న హಾರ్డ్‌వేర్'
  },
  explorer_comp_info: {
    en: 'COMPONENT INFORMATION',
    hi: 'घटक जानकारी',
    kn: 'ಘಟಕ ಮಾಹಿತಿ',
    ta: 'கூறு விவரம்',
    te: 'భాగం సమాచారం'
  },
  explorer_position: {
    en: 'POSITION', hi: 'स्थिति', kn: 'ಸ್ಥಾನ', ta: 'நிலை', te: 'స్థానం'
  },
  explorer_id: {
    en: 'ID', hi: 'आईडी', kn: 'ಐಡಿ', ta: 'ஐடி', te: 'ఐడి'
  },
  explorer_hint_move: {
    en: 'Move mode: click a new position on the workbench to reposition the selected component.',
    hi: 'स्थानांतर मोड: चयनित घटक को नए स्थान पर रखने के लिए workbench पर क्लिक करें।',
    kn: 'ಸ್ಥಳಾಂತರ ಮೋಡ್: ಆಯ್ದ ಘಟಕವನ್ನು ಹೊಸ ಸ್ಥಳಕ್ಕೆ ಜರುಗಿಸಲು workbench ಕ್ಲಿಕ್ ಮಾಡಿ.',
    ta: 'நகர்த்தல் முறை: தேர்ந்தெடுத்த கூறினை புதிய இடத்திற்கு நகர்த்த workbench-ல் கிளிக் செய்.',
    te: 'తరలింపు మోడ్: ఎంచుకున్న భాగాన్ని కొత్త స్థానానికి తరలించడానికి workbench క్లిక్ చేయండి.'
  },
  explorer_hint_place: {
    en: 'Placement mode: click the workbench to place',
    hi: 'स्थापन मोड: घटक रखने के लिए workbench पर क्लिक करें',
    kn: 'ಸ್ಥಾಪನೆ ಮೋಡ್: ಘಟಕ ಇರಿಸಲು workbench ಕ್ಲಿಕ್ ಮಾಡಿ',
    ta: 'நிலைப்படுத்தல் முறை: கூறினை வைக்க workbench கிளிக் செய்',
    te: 'స్థాపన మోడ్: భాగం ఉంచడానికి workbench క్లిక్ చేయండి'
  },
  explorer_hint_selected: {
    en: 'Selected:', hi: 'चयनित:', kn: 'ಆಯ್ದ:', ta: 'தேர்ந்தெடுத்த:', te: 'ఎంచుకున్న:'
  },
  explorer_hint_edit: {
    en: 'Use Move, Rotate or Remove to edit it.',
    hi: 'संपादन के लिए Move, Rotate या Remove का उपयोग करें।',
    kn: 'ಸಂಪಾದಿಸಲು Move, Rotate ಅಥವಾ Remove ಬಳಸಿ.',
    ta: 'திருத்த Move, Rotate அல்லது Remove பயன்படுத்து.',
    te: 'సవరించడానికి Move, Rotate లేదా Remove వాడండి.'
  },
  explorer_hint_choose: {
    en: 'Choose a component below, drag it into the workbench, or select a placed component to edit it.',
    hi: 'नीचे से घटक चुनें, workbench में खींचें, या रखे गए घटक को संपादित करें।',
    kn: 'ಕೆಳಗಿಂದ ಘಟಕ ಆಯ್ಕೆ, workbench ಗೆ ಎಳೆಯಿರಿ, ಅಥವಾ ಇರಿಸಿದ ಘಟಕವನ್ನು ಸಂಪಾದಿಸಿ.',
    ta: 'கீழே கூறு தேர்வு செய், workbench-க்கு இழு, அல்லது வைக்கப்பட்ட கூறினை திருத்து.',
    te: 'క్రింద భాగం ఎంచుకోండి, workbench కి లాగండి, లేదా ఉంచిన భాగాన్ని సవరించండి.'
  },
  explorer_the_component: {
    en: 'the component', hi: 'घटक', kn: 'ಘಟಕ', ta: 'கூறு', te: 'భాగం'
  },

  // ─── UserManagement ────────────────────────────────────────────────────────
  um_title: {
    en: 'User Management',
    hi: 'उपयोगकर्ता प्रबंधन',
    kn: 'ಬಳಕೆದಾರ ನಿರ್ವಹಣೆ',
    ta: 'பயனர் நிர்வாகம்',
    te: 'వినియోగదారు నిర్వాహణ'
  },
  um_create_user: {
    en: 'Create User',
    hi: 'उपयोगकर्ता बनाएं',
    kn: 'ಬಳಕೆದಾರ ರಚಿಸಿ',
    ta: 'பயனர் உருவாக்கு',
    te: 'వినియోగదారు సృష్టించు'
  },
  um_err_create: {
    en: 'Failed to create user.',
    hi: 'उपयोगकर्ता बनाने में विफल।',
    kn: 'ಬಳಕೆದಾರ ರಚಿಸಲು ವಿಫಲ.',
    ta: 'பயனர் உருவாக்க முடியவில்லை.',
    te: 'వినియోగదారు సృష్టించడం విఫలమైంది.'
  },
  um_err_status: {
    en: 'Could not update user status.',
    hi: 'उपयोगकर्ता स्थिति अपडेट नहीं हो सकी।',
    kn: 'ಬಳಕೆದಾರ ಸ್ಥಿತಿ ಅಪ್‌ಡೇಟ್ ಆಗಲಿಲ್ಲ.',
    ta: 'பயனர் நிலை புதுப்பிக்க முடியவில்லை.',
    te: 'వినియోగదారు స్థితి అప్‌డేట్ చేయలేకపోయింది.'
  },
  um_err_delete: {
    en: 'Could not delete user.',
    hi: 'उपयोगकर्ता हटाने में विफल।',
    kn: 'ಬಳಕೆದಾರ ಅಳಿಸಲು ವಿಫಲ.',
    ta: 'பயனரை நீக்க முடியவில்லை.',
    te: 'వినియోగదారును తొలగించడం విఫలమైంది.'
  },
  um_err_network: {
    en: 'Network error.',
    hi: 'नेटवर्क त्रुटि।',
    kn: 'ನೆಟ್‌ವರ್ಕ್ ದೋಷ.',
    ta: 'நெட்வொர்க் பிழை.',
    te: 'నెట్‌వర్క్ లోపం.'
  },
  um_err_invite: {
    en: 'Failed to generate invite.',
    hi: 'आमंत्रण जनरेट करने में विफल।',
    kn: 'ಆಮಂತ್ರಣ ಜನರೇಟ್ ಮಾಡಲು ವಿಫಲ.',
    ta: 'அழைப்பு உருவாக்க முடியவில்லை.',
    te: 'ఆహ్వాన జనరేట్ చేయడం విఫలమైంది.'
  },
  um_total: {
    en: 'Total Users',
    hi: 'कुल उपयोगकर्ता',
    kn: 'ಒಟ್ಟು ಬಳಕೆದಾರರು',
    ta: 'மொத்த பயனர்கள்',
    te: 'మొత్తం వినియోగదారులు'
  },
  um_active: {
    en: 'active', hi: 'सक्रिय', kn: 'ಸಕ್ರಿಯ', ta: 'செயலில்', te: 'క్రియాశీలం'
  },
  um_loading: {
    en: 'Loading users…',
    hi: 'उपयोगकर्ता लोड हो रहे हैं…',
    kn: 'ಬಳಕೆದಾರರನ್ನು ಲೋಡ್ ಮಾಡಲಾಗುತ್ತಿದೆ…',
    ta: 'பயனர்களை ஏற்றுகிறது…',
    te: 'వినియోగదారులను లోడ్ చేస్తోంది…'
  },
  um_th_status: {
    en: 'Status', hi: 'स्थिति', kn: 'ಸ್ಥಿತಿ', ta: 'நிலை', te: 'స్థితి'
  },
  um_th_username: {
    en: 'Username',
    hi: 'उपयोगकर्ता नाम',
    kn: 'ಬಳಕೆದಾರ ಹೆಸರು',
    ta: 'பயனர் பெயர்',
    te: 'వినియోగదారు పేరు'
  },
  um_th_name: {
    en: 'Full Name',
    hi: 'पूरा नाम',
    kn: 'ಪೂರ್ಣ ಹೆಸರು',
    ta: 'முழு பெயர்',
    te: 'పూర్తి పేరు'
  },
  um_th_role: {
    en: 'Role', hi: 'भूमिका', kn: 'ಪಾತ್ರ', ta: 'பங்கு', te: 'పాత్ర'
  },
  um_th_created: {
    en: 'Created',
    hi: 'बनाया',
    kn: 'ರಚಿಸಲಾಗಿದೆ',
    ta: 'உருவாக்கப்பட்டது',
    te: 'సృష్టించబడింది'
  },
  um_th_login: {
    en: 'Last Login',
    hi: 'अंतिम लॉगिन',
    kn: 'ಕೊನೆಯ ಲಾಗಿನ್',
    ta: 'கடைசி உள்நுழைவு',
    te: 'చివరి లాగిన్'
  },
  um_th_actions: {
    en: 'Actions', hi: 'कार्य', kn: 'ಕ್ರಿಯೆಗಳು', ta: 'செயல்கள்', te: 'చర్యలు'
  },
  um_activate: {
    en: 'Activate', hi: 'सक्रिय करें', kn: 'ಸಕ್ರಿಯಗೊಳಿಸಿ', ta: 'செயல்படுத்து', te: 'క్రియాశీలం చేయి'
  },
  um_deactivate: {
    en: 'Deactivate', hi: 'निष्क्रिय करें', kn: 'ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ', ta: 'செயலிழக்கச் செய்', te: 'నిష్క్రియం చేయి'
  },
  um_status_active: {
    en: 'Active', hi: 'सक्रिय', kn: 'ಸಕ್ರಿಯ', ta: 'செயலில்', te: 'క్రియాశీలం'
  },
  um_status_inactive: {
    en: 'Inactive', hi: 'निष्क्रिय', kn: 'ನಿಷ್ಕ್ರಿಯ', ta: 'செயலற்ற', te: 'నిష్క్రియం'
  },
  um_cant_self: {
    en: 'Cannot change your own status',
    hi: 'अपनी स्थिति नहीं बदल सकते',
    kn: 'ನಿಮ್ಮ ಸ್ಥಿತಿ ಬದಲಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ',
    ta: 'உங்கள் நிலையை மாற்ற முடியாது',
    te: 'మీ స్థితిని మార్చలేరు'
  },
  um_delete: {
    en: 'Delete account permanently',
    hi: 'खाता स्थायी रूप से हटाएं',
    kn: 'ಖಾತೆ ಶಾಶ್ವತವಾಗಿ ಅಳಿಸಿ',
    ta: 'கணக்கை நிரந்தரமாக நீக்கு',
    te: 'ఖాతాను శాశ్వతంగా తొలగించు'
  },
  um_delete_btn: {
    en: '🗑 Delete', hi: '🗑 हटाएं', kn: '🗑 ಅಳಿಸಿ', ta: '🗑 நீக்கு', te: '🗑 తొలగించు'
  },

  // ─── Role-segmented Create Account panels ──────────────────────────────────
  create_acct_heading: {
    en: 'Create Account',
    hi: 'खाता बनाएं',
    kn: 'ಖಾತೆ ರಚಿಸಿ',
    ta: 'கணக்கு உருவாக்கு',
    te: 'ఖాతా సృష్టించు'
  },
  create_acct_sub: {
    en: 'Choose your role to get started',
    hi: 'शुरू करने के लिए अपनी भूमिका चुनें',
    kn: 'ಪ್ರಾರಂಭಿಸಲು ನಿಮ್ಮ ಪಾತ್ರ ಆರಿಸಿ',
    ta: 'தொடங்க உங்கள் பங்கை தேர்வு செய்',
    te: 'ప్రారంభించడానికి మీ పాత్ర ఎంచుకోండి'
  },
  already_have_account: {
    en: 'Already have an account?',
    hi: 'पहले से खाता है?',
    kn: 'ಈಗಾಗಲೇ ಖಾತೆ ಇದೆಯೇ?',
    ta: 'ஏற்கனவே கணக்கு உள்ளதா?',
    te: 'ఇప్పటికే ఖాతా ఉందా?'
  },
  back_to_sign_in: {
    en: 'Sign in instead',
    hi: 'साइन इन करें',
    kn: 'ಸೈನ್ ಇನ್ ಮಾಡಿ',
    ta: 'உள்நுழைக',
    te: 'సైన్ ఇన్ చేయండి'
  },
  op_reg_title: {
    en: '📊 Operator Account',
    hi: '📊 ऑपरेटर खाता',
    kn: '📊 ಆಪರೇಟರ್ ಖಾತೆ',
    ta: '📊 இயக்குனர் கணக்கு',
    te: '📊 ఆపరేటర్ ఖాతా'
  },
  op_reg_desc: {
    en: 'Monitor dashboards, review sensor data, and submit labels for anomaly verification.',
    hi: 'डैशबोर्ड देखें, सेंसर डेटा की समीक्षा करें और anomaly सत्यापन के लिए लेबल सबमिट करें।',
    kn: 'Dashboards ಮೇಲ್ವಿಚಾರಣೆ, sensor ಡೇಟಾ ಪರಿಶೀಲನೆ ಮತ್ತು anomaly labels ಸಲ್ಲಿಸಿ.',
    ta: 'டாஷ்போர்டுகளை கண்காணி, சென்சார் தரவை மதிப்பாய்வு செய், முரண்பாட்டு சரிபார்ப்பிற்கு லேபல்கள் சமர்ப்பி.',
    te: 'డాష్‌బోర్డ్‌లు పర్యవేక్షించండి, సెన్సర్ డేటా సమీక్షించండి, అనామలీ ధృవీకరణకు లేబుల్‌లు సమర్పించండి.'
  },
  eng_reg_title: {
    en: '🔧 Engineer Account',
    hi: '🔧 इंजीनियर खाता',
    kn: '🔧 ಇಂಜಿನಿಯರ್ ಖಾತೆ',
    ta: '🔧 பொறியாளர் கணக்கு',
    te: '🔧 ఇంజినీర్ ఖాతా'
  },
  eng_reg_desc: {
    en: 'Access equipment controls, dispatch maintenance commands, and manage sensor calibration.',
    hi: 'उपकरण नियंत्रण, रखरखाव आदेश और सेंसर कैलिब्रेशन प्रबंधित करें।',
    kn: 'ಉಪಕರಣ ನಿಯಂತ್ರಣ, ನಿರ್ವಹಣಾ ಆದೇಶಗಳು ಮತ್ತು sensor calibration ನಿರ್ವಹಿಸಿ.',
    ta: 'உபகரண கட்டுப்பாடுகளை அணுகு, பராமரிப்பு கட்டளைகளை அனுப்பு, சென்சார் அளவீட்டு நிர்வகி.',
    te: 'పరికర నియంత్రణలు యాక్సెస్ చేయండి, నిర్వహణ ఆదేశాలు పంపండి, సెన్సర్ క్రమాంకనం నిర్వహించండి.'
  },
  btn_create_op: {
    en: '→ Create Operator Account',
    hi: '→ ऑपरेटर खाता बनाएं',
    kn: '→ ಆಪರೇಟರ್ ಖಾತೆ ರಚಿಸಿ',
    ta: '→ இயக்குனர் கணக்கு உருவாக்கு',
    te: '→ ఆపరేటర్ ఖాతా సృష్టించు'
  },
  btn_create_eng: {
    en: '→ Create Engineer Account',
    hi: '→ इंजीनियर खाता बनाएं',
    kn: '→ ಇಂಜಿನಿಯರ್ ಖಾತೆ ರಚಿಸಿ',
    ta: '→ பொறியாளர் கணக்கு உருவாக்கு',
    te: '→ ఇంజినీర్ ఖాతా సృష్టించు'
  },
  modal_op_title: {
    en: '📊 Create Operator Account',
    hi: '📊 ऑपरेटर खाता बनाएं',
    kn: '📊 ಆಪರೇಟರ್ ಖಾತೆ ರಚಿಸಿ',
    ta: '📊 இயக்குனர் கணக்கு உருவாக்கு',
    te: '📊 ఆపరేటర్ ఖాతా సృష్టించు'
  },
  modal_eng_title: {
    en: '🔧 Create Engineer Account',
    hi: '🔧 इंजीनियर खाता बनाएं',
    kn: '🔧 ಇಂಜಿನಿಯರ್ ಖಾತೆ ರಚಿಸಿ',
    ta: '🔧 பொறியாளர் கணக்கு உருவாக்கு',
    te: '🔧 ఇంజినీర్ ఖాతా సృష్టించు'
  },
  acct_created_op: {
    en: 'Operator account created! You can now sign in.',
    hi: 'ऑपरेटर खाता बनाया! अब साइन इन करें।',
    kn: 'ಆಪರೇಟರ್ ಖಾತೆ ರಚಿಸಲಾಗಿದೆ! ಈಗ ಸೈನ್ ಇನ್ ಮಾಡಿ.',
    ta: 'இயக்குனர் கணக்கு உருவாக்கப்பட்டது!',
    te: 'ఆపరేటర్ ఖాతా సృష్టించబడింది!'
  },
  acct_created_eng: {
    en: 'Engineer account created! You can now sign in.',
    hi: 'इंजीनियर खाता बनाया! अब साइन इन करें।',
    kn: 'ಇಂಜಿನಿಯರ್ ಖಾತೆ ರಚಿಸಲಾಗಿದೆ! ಈಗ ಸೈನ್ ಇನ್ ಮಾಡಿ.',
    ta: 'பொறியாளர் கணக்கு உருவாக்கப்பட்டது!',
    te: 'ఇంజినీర్ ఖాతా సృష్టించబడింది!'
  },
  reg_invite_notice: {
    en: 'You need an invite code from your administrator to create an account.',
    hi: 'खाता बनाने के लिए आपको अपने admin से invite code चाहिए।',
    kn: 'ಖಾತೆ ರಚಿಸಲು ನಿಮ್ಮ admin ನಿಂದ invite code ಅಗತ್ಯ.',
    ta: 'கணக்கு உருவாக்க உங்கள் நிர்வாகியிடமிருந்து அழைப்பு குறியீடு தேவை.',
    te: 'ఖాతా సృష్టించడానికి మీ నిర్వాహకుడి నుండి ఆహ్వాన కోడ్ అవసరం.'
  },
  ph_full_name: {
    en: 'Your full name',
    hi: 'आपका पूरा नाम',
    kn: 'ನಿಮ್ಮ ಪೂರ್ಣ ಹೆಸರು',
    ta: 'உங்கள் முழு பெயர்',
    te: 'మీ పూర్తి పేరు'
  },
}

// ── Runtime lang state ──────────────────────────────────────────────────────
const isSupportedLanguage = (code) =>
  SUPPORTED_LANGUAGES.some(language => language.code === code)

let _currentLang = (() => {
  try {
    const savedLang = localStorage.getItem('iw_lang')
    return isSupportedLanguage(savedLang) ? savedLang : 'en'
  } catch {
    return 'en'
  }
})()

const _listeners = new Set()

export function getLang() {
  return _currentLang
}

export function setLang(code) {
  if (!isSupportedLanguage(code)) return

  _currentLang = code

  try {
    localStorage.setItem('iw_lang', code)
  } catch {
    // Language selection still works for the current session.
  }

  _listeners.forEach(fn => {
    try {
      fn(code)
    } catch (error) {
      console.error('IntelliWatch language listener error:', error)
    }
  })
}

export function subscribeLang(fn) {
  if (typeof fn !== 'function') {
    throw new TypeError('subscribeLang expects a function.')
  }

  _listeners.add(fn)
  return () => _listeners.delete(fn)
}

/** Translate a key. Falls back to English, then to the key itself. */
export function t(key, lang) {
  const use = isSupportedLanguage(lang) ? lang : _currentLang
  const row = TRANSLATIONS[key]

  if (!row) return key

  return row[use] || row.en || key
}